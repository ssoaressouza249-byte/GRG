package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.hardware.DeviceTelemetryReader
import com.example.hardware.PhoneBrand
import com.example.security.SecurityGuard
import com.example.security.TamperCheckResult
import com.example.shizuku.FangrxshotManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `app identity and security guard pass`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    assertEquals("GRX LENTO", context.getString(R.string.app_name))
    assertEquals("com.raylan.grxlento", context.packageName)

    val result = SecurityGuard.verify(context)
    assertTrue(result is TamperCheckResult.Verified)
  }

  @Test
  fun `brand detection and fangrxshot command count are valid`() {
    assertEquals(PhoneBrand.SAMSUNG, DeviceTelemetryReader.mapManufacturerToBrand("samsung"))
    assertEquals(PhoneBrand.XIAOMI_POCO, DeviceTelemetryReader.mapManufacturerToBrand("Xiaomi"))
    assertEquals(50, FangrxshotManager.COMMANDS.size)
  }
}
