package com.example.hardware

import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.util.DisplayMetrics
import android.view.Display
import android.view.WindowManager
import kotlin.math.roundToInt

enum class PhoneBrand(val label: String) {
    SAMSUNG("Samsung"),
    XIAOMI_POCO("Xiaomi / Poco"),
    MOTOROLA("Motorola"),
    REALME("Realme"),
    ASUS_ROG("Asus ROG"),
    INFINIX_TECNO("Infinix / Tecno"),
    IPHONE_IOS("iPhone (iOS)"),
    OTHER_ANDROID("Outro Android")
}

enum class PlayStyle(val label: String, val shortDesc: String) {
    ONE_TAP("Subir Capa (One-Tap)", "Foco em puxada precisa e fixação na cabeça"),
    RUSH_MOVEMENT("Movimentação & Rush Rápido", "Giro 360° ágil e gelo rápido em curta distância"),
    BONECO_LENTO("Boneco Lento (Controle Máximo)", "Estabilidade pesada contra tremedeira de mira")
}

data class DeviceHardwareInfo(
    val manufacturer: String,
    val modelName: String,
    val resolution: String,
    val widthPx: Int,
    val heightPx: Int,
    val dpi: Int,
    val refreshRateHz: Int,
    val detectedBrand: PhoneBrand
)

object DeviceTelemetryReader {

    @Suppress("DEPRECATION")
    fun read(context: Context): DeviceHardwareInfo {
        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val displayMetrics = DisplayMetrics()

        var widthPx = context.resources.displayMetrics.widthPixels
        var heightPx = context.resources.displayMetrics.heightPixels
        var dpi = context.resources.displayMetrics.densityDpi

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = windowManager.currentWindowMetrics.bounds
            if (bounds.width() > 0 && bounds.height() > 0) {
                widthPx = bounds.width()
                heightPx = bounds.height()
            }
            val configDpi = context.resources.configuration.densityDpi
            if (configDpi > 0) dpi = configDpi
        } else {
            windowManager.defaultDisplay?.getRealMetrics(displayMetrics)
            if (displayMetrics.widthPixels > 0 && displayMetrics.heightPixels > 0) {
                widthPx = displayMetrics.widthPixels
                heightPx = displayMetrics.heightPixels
                dpi = displayMetrics.densityDpi
            }
        }

        val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
        val display = displayManager?.getDisplay(Display.DEFAULT_DISPLAY)
            ?: if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) context.display else windowManager.defaultDisplay
        val refreshRateHz = (display?.refreshRate ?: 60f).roundToInt().coerceAtLeast(60)

        val rawManufacturer = Build.MANUFACTURER.orEmpty().trim()
        val rawModel = Build.MODEL.orEmpty().trim()
        val fullModel = if (rawModel.startsWith(rawManufacturer, ignoreCase = true)) {
            rawModel
        } else {
            "$rawManufacturer $rawModel".trim()
        }

        return DeviceHardwareInfo(
            manufacturer = rawManufacturer.ifBlank { "Android" },
            modelName = fullModel.ifBlank { "Dispositivo Android" },
            resolution = "${widthPx}x${heightPx}",
            widthPx = widthPx,
            heightPx = heightPx,
            dpi = dpi,
            refreshRateHz = refreshRateHz,
            detectedBrand = mapManufacturerToBrand(rawManufacturer)
        )
    }

    fun mapManufacturerToBrand(manufacturer: String): PhoneBrand {
        val m = manufacturer.lowercase()
        return when {
            m.contains("samsung") -> PhoneBrand.SAMSUNG
            m.contains("xiaomi") || m.contains("redmi") || m.contains("poco") -> PhoneBrand.XIAOMI_POCO
            m.contains("motorola") || m.contains("moto") -> PhoneBrand.MOTOROLA
            m.contains("realme") -> PhoneBrand.REALME
            m.contains("asus") || m.contains("rog") -> PhoneBrand.ASUS_ROG
            m.contains("infinix") || m.contains("tecno") || m.contains("itel") -> PhoneBrand.INFINIX_TECNO
            else -> PhoneBrand.OTHER_ANDROID
        }
    }
}
