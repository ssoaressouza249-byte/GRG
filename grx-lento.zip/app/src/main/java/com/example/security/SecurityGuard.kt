package com.example.security

import android.content.Context
import java.security.MessageDigest

sealed interface TamperCheckResult {
    data class Verified(
        val appLabel: String,
        val packageName: String,
        val authorHashValid: Boolean
    ) : TamperCheckResult

    data class Blocked(
        val violationReason: String,
        val observedPackage: String,
        val observedLabel: String
    ) : TamperCheckResult
}

object SecurityGuard {
    private const val EXPECTED_APP_LABEL = "GRX LENTO"
    private const val EXPECTED_PACKAGE_NAME = "com.raylan.grxlento"

    private const val AUTHOR_SHORT = "RAYLAN"
    private const val AUTHOR_FULL = "RAYLAN GRX"
    private const val PRODUCT_NAME = "GRX LENTO"

    private const val HASH_AUTHOR_SHORT =
        "baa6d2ad8064d835b78444ff1a5bc2e388759342e28fb1de968065cf4e862eec"
    private const val HASH_AUTHOR_FULL =
        "d320c08a3c78656342c0455c8009401ff287a38f5436f83e3889de5d9941ca98"
    private const val HASH_PRODUCT_NAME =
        "1dc0878c2ff8279e91507c9fd3b311cc9541e11349d091958fed69584908d82c"

    const val BLOCKED_MESSAGE =
        "VIOLAÇÃO DE INTEGRIDADE: Este aplicativo original pertence exclusivamente ao criador RAYLAN GRX. Modificações não são permitidas."

    fun verify(context: Context): TamperCheckResult {
        val observedPackage = context.packageName
        val observedLabel = runCatching {
            context.applicationInfo.loadLabel(context.packageManager).toString()
        }.getOrDefault("")

        if (observedLabel != EXPECTED_APP_LABEL) {
            return TamperCheckResult.Blocked(
                violationReason = "Nome do aplicativo adulterado ($observedLabel)",
                observedPackage = observedPackage,
                observedLabel = observedLabel
            )
        }

        if (observedPackage != EXPECTED_PACKAGE_NAME) {
            return TamperCheckResult.Blocked(
                violationReason = "Pacote do aplicativo adulterado ($observedPackage)",
                observedPackage = observedPackage,
                observedLabel = observedLabel
            )
        }

        val authorShortOk = sha256(AUTHOR_SHORT) == HASH_AUTHOR_SHORT
        val authorFullOk = sha256(AUTHOR_FULL) == HASH_AUTHOR_FULL
        val productNameOk = sha256(PRODUCT_NAME) == HASH_PRODUCT_NAME

        if (!authorShortOk || !authorFullOk || !productNameOk) {
            return TamperCheckResult.Blocked(
                violationReason = "Assinatura SHA-256 das constantes do criador violada",
                observedPackage = observedPackage,
                observedLabel = observedLabel
            )
        }

        return TamperCheckResult.Verified(
            appLabel = observedLabel,
            packageName = observedPackage,
            authorHashValid = true
        )
    }

    fun isIntact(context: Context): Boolean = verify(context) is TamperCheckResult.Verified

    fun sha256(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString(separator = "") { byte ->
            "%02x".format(byte)
        }
    }
}
