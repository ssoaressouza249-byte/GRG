package com.example.export

import android.app.DownloadManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.example.ai.SensitivityProfile
import com.example.hardware.DeviceHardwareInfo
import com.example.security.SecurityGuard
import com.example.shizuku.FangrxshotManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class ExportedPackResult(
    val fileName: String,
    val displayPath: String,
    val contentUri: Uri?
)

object PackExporter {

    suspend fun exportOptimizationPack(
        context: Context,
        hardware: DeviceHardwareInfo,
        sensitivity: SensitivityProfile?
    ): Result<ExportedPackResult> = withContext(Dispatchers.IO) {
        if (!SecurityGuard.isIntact(context)) {
            return@withContext Result.failure(
                SecurityException(SecurityGuard.BLOCKED_MESSAGE)
            )
        }

        runCatching {
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val fileName = "GRX_LENTO_PACK_RAYLAN_$timestamp.zip"
            val zipBytes = buildZipBytes(hardware, sensitivity, timestamp)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                    put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }

                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: error("Não foi possível criar arquivo na pasta Download.")

                resolver.openOutputStream(uri)?.use { out ->
                    out.write(zipBytes)
                    out.flush()
                } ?: error("Falha ao abrir fluxo de escrita em Download.")

                values.clear()
                values.put(MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(uri, values, null, null)

                ExportedPackResult(
                    fileName = fileName,
                    displayPath = "Download/$fileName",
                    contentUri = uri
                )
            } else {
                @Suppress("DEPRECATION")
                val downloadsDir = Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOWNLOADS
                )
                if (!downloadsDir.exists()) downloadsDir.mkdirs()
                val outFile = File(downloadsDir, fileName)
                FileOutputStream(outFile).use { out ->
                    out.write(zipBytes)
                    out.flush()
                }
                ExportedPackResult(
                    fileName = fileName,
                    displayPath = outFile.absolutePath,
                    contentUri = Uri.fromFile(outFile)
                )
            }
        }
    }

    private fun buildZipBytes(
        hardware: DeviceHardwareInfo,
        sensitivity: SensitivityProfile?,
        timestamp: String
    ): ByteArray {
        val baos = ByteArrayOutputStream()
        ZipOutputStream(baos).use { zos ->
            // 1. fangrxshot_commands.sh
            val shContent = buildString {
                appendLine("#!/system/bin/sh")
                appendLine("# ========================================================")
                appendLine("# GRX LENTO - FANGRXSHOT SHIZUKU / ADB OPTIMIZATION SCRIPT")
                appendLine("# CRIADOR OFICIAL: RAYLAN GRX")
                appendLine("# PACOTE OFICIAL: com.raylan.grxlento")
                appendLine("# GERADO EM: $timestamp")
                appendLine("# ========================================================")
                appendLine()
                FangrxshotManager.COMMANDS.forEach { cmd ->
                    appendLine("$cmd 2>/dev/null || true")
                }
            }
            zos.putNextEntry(ZipEntry("fangrxshot_commands.sh"))
            zos.write(shContent.toByteArray(Charsets.UTF_8))
            zos.closeEntry()

            // 2. grx_boneco_lento_sensi.cfg
            val cfgContent = buildString {
                appendLine("# GRX LENTO - PERFIL BONECO LENTO & SENSIBILIDADE")
                appendLine("# CRIADOR: RAYLAN GRX")
                appendLine("device_model=${hardware.modelName}")
                appendLine("screen_resolution=${hardware.resolution}")
                appendLine("current_dpi=${hardware.dpi}")
                appendLine("refresh_rate_hz=${hardware.refreshRateHz}")
                appendLine("vpn_dns_primary=1.1.1.1")
                appendLine("vpn_dns_secondary=8.8.8.8")
                appendLine("vpn_mtu=1400")
                appendLine("boneco_lento_mode=ACTIVE")
                appendLine()
                if (sensitivity != null) {
                    appendLine("[AI_SENSITIVITY_PROFILE]")
                    appendLine("brand=${sensitivity.brand}")
                    appendLine("playstyle=${sensitivity.playstyle}")
                    appendLine("geral=${sensitivity.geral}")
                    appendLine("ponto_vermelho=${sensitivity.pontoVermelho}")
                    appendLine("mira_2x=${sensitivity.mira2x}")
                    appendLine("mira_4x=${sensitivity.mira4x}")
                    appendLine("awm=${sensitivity.awm}")
                    appendLine("olhadinha=${sensitivity.olhadinha}")
                    appendLine("dpi_recomendada=${sensitivity.dpiRecomendada}")
                    appendLine("botao_tiro=${sensitivity.tamanhoBotaoTiro}")
                    appendLine("velocidade_ponteiro=${sensitivity.velocidadePonteiro}")
                } else {
                    appendLine("[DEFAULT_BONECO_LENTO_PROFILE]")
                    appendLine("geral=168")
                    appendLine("ponto_vermelho=154")
                    appendLine("mira_2x=142")
                    appendLine("mira_4x=126")
                    appendLine("awm=88")
                    appendLine("olhadinha=118")
                    appendLine("dpi_recomendada=${(hardware.dpi + 180).coerceIn(480, 960)}")
                    appendLine("botao_tiro=46%")
                    appendLine("velocidade_ponteiro=7 (Máxima)")
                }
            }
            zos.putNextEntry(ZipEntry("grx_boneco_lento_sensi.cfg"))
            zos.write(cfgContent.toByteArray(Charsets.UTF_8))
            zos.closeEntry()

            // 3. LEIA_ME_RAYLAN.txt
            val readmeContent = buildString {
                appendLine("==========================================================")
                appendLine("       GRX LENTO — PACK OFICIAL DE OTIMIZAÇÃO GAMING      ")
                appendLine("                CRIADOR: RAYLAN GRX                       ")
                appendLine("==========================================================")
                appendLine()
                appendLine("Aparelho detectado: ${hardware.modelName}")
                appendLine("Resolução: ${hardware.resolution} | DPI: ${hardware.dpi} | Taxa: ${hardware.refreshRateHz}Hz")
                appendLine()
                appendLine("ARQUIVOS INCLUÍDOS NESTE PACK:")
                appendLine("1. fangrxshot_commands.sh -> Comandos ADB/Shizuku de resposta tátil e Vulkan/HWUI.")
                appendLine("2. grx_boneco_lento_sensi.cfg -> Parâmetros de sensibilidade, DPI, DNS 1.1.1.1/8.8.8.8 e MTU 1400.")
                appendLine("3. LEIA_ME_RAYLAN.txt -> Guia oficial do criador RAYLAN GRX.")
                appendLine()
                appendLine("AVISO DE AUTENTICIDADE:")
                appendLine("Aplicativo original desenvolvido por RAYLAN GRX (com.raylan.grxlento).")
            }
            zos.putNextEntry(ZipEntry("LEIA_ME_RAYLAN.txt"))
            zos.write(readmeContent.toByteArray(Charsets.UTF_8))
            zos.closeEntry()
        }
        return baos.toByteArray()
    }

    fun openDownloadsFolder(context: Context) {
        val viewDownloadsIntent = Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val opened = runCatching {
            context.startActivity(viewDownloadsIntent)
            true
        }.getOrDefault(false)

        if (!opened) {
            runCatching {
                val fallback = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(fallback)
            }
        }
    }
}
