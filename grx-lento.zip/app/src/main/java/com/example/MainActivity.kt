package com.example

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.security.SecurityGuard
import com.example.security.TamperCheckResult
import com.example.security.configureAppCheck
import com.example.ui.GrxViewModel
import com.example.ui.components.ElectricLightningBackground
import com.example.ui.components.GrxMandatoryFooter
import com.example.ui.components.GrxTab
import com.example.ui.components.GrxTopHeader
import com.example.ui.screens.CriadorRaylanTab
import com.example.ui.screens.GerarSensiTab
import com.example.ui.screens.PainelGrxTab
import com.example.ui.screens.TamperBlockedScreen
import com.example.ui.theme.GrxLentoTheme
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {

    private val viewModel: GrxViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure Firebase App Check with launch Intent before any UI or Firebase calls
        configureAppCheck(this, intent)

        // STEP 2: Verify anti-tamper integrity before rendering main UI
        val initialIntegrity = SecurityGuard.verify(this)

        enableEdgeToEdge()
        setContent {
            GrxLentoTheme {
                val tamperState by viewModel.tamperResult.collectAsStateWithLifecycle()
                val activeTamper = if (initialIntegrity is TamperCheckResult.Blocked) {
                    initialIntegrity
                } else {
                    tamperState
                }

                when (activeTamper) {
                    is TamperCheckResult.Blocked -> {
                        TamperBlockedScreen(blocked = activeTamper)
                    }

                    is TamperCheckResult.Verified -> {
                        GrxLentoAppRoot(viewModel = viewModel)
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshSecurityAndHardware()
    }
}

@Composable
private fun GrxLentoAppRoot(
    viewModel: GrxViewModel
) {
    val context = LocalContext.current
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val tamperResult by viewModel.tamperResult.collectAsStateWithLifecycle()
    val hardwareInfo by viewModel.hardwareInfo.collectAsStateWithLifecycle()
    val isVpnActive by viewModel.isVpnActive.collectAsStateWithLifecycle()
    val vpnStatusLog by viewModel.vpnStatusLog.collectAsStateWithLifecycle()
    val shizukuConnected by viewModel.shizukuConnected.collectAsStateWithLifecycle()
    val shizukuPermissionGranted by viewModel.shizukuPermissionGranted.collectAsStateWithLifecycle()
    val fangrxshotActive by viewModel.fangrxshotActive.collectAsStateWithLifecycle()
    val fangrxshotRunning by viewModel.fangrxshotRunning.collectAsStateWithLifecycle()
    val fangrxshotSucceededCount by viewModel.fangrxshotSucceededCount.collectAsStateWithLifecycle()
    val fangrxshotLogs by viewModel.fangrxshotLogs.collectAsStateWithLifecycle()
    val packExportState by viewModel.packExportState.collectAsStateWithLifecycle()
    val selectedBrand by viewModel.selectedBrand.collectAsStateWithLifecycle()
    val selectedPlayStyle by viewModel.selectedPlayStyle.collectAsStateWithLifecycle()
    val sensitivityAiState by viewModel.sensitivityAiState.collectAsStateWithLifecycle()

    // Register Shizuku lifecycle listeners
    DisposableEffect(Unit) {
        val binderReceivedListener = Shizuku.OnBinderReceivedListener {
            viewModel.refreshShizukuStatus()
        }
        val binderDeadListener = Shizuku.OnBinderDeadListener {
            viewModel.refreshShizukuStatus()
        }
        val permissionResultListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            viewModel.onShizukuPermissionResult(requestCode, grantResult)
        }

        runCatching {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(permissionResultListener)
        }

        onDispose {
            runCatching {
                Shizuku.removeBinderReceivedListener(binderReceivedListener)
                Shizuku.removeBinderDeadListener(binderDeadListener)
                Shizuku.removeRequestPermissionResultListener(permissionResultListener)
            }
        }
    }

    // Standard Android VPN preparation launcher
    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            viewModel.startVpnService()
        }
    }

    // Optional Android 13+ notification permission launcher so VPN status notification is visible
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        val prepareIntent = viewModel.prepareVpnIntent()
        if (prepareIntent != null) {
            vpnPermissionLauncher.launch(prepareIntent)
        } else {
            viewModel.startVpnService()
        }
    }

    val handleToggleVpn: () -> Unit = {
        if (isVpnActive) {
            viewModel.stopVpnService()
        } else {
            val needsNotificationPrompt = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED

            if (needsNotificationPrompt) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                val prepareIntent = viewModel.prepareVpnIntent()
                if (prepareIntent != null) {
                    vpnPermissionLauncher.launch(prepareIntent)
                } else {
                    viewModel.startVpnService()
                }
            }
        }
    }

    ElectricLightningBackground {
        Scaffold(
            containerColor = Color.Transparent,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            topBar = {
                GrxTopHeader(
                    selectedTab = selectedTab,
                    onSelectTab = viewModel::selectTab
                )
            },
            bottomBar = {
                GrxMandatoryFooter()
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (selectedTab) {
                    GrxTab.PAINEL_GRX -> {
                        PainelGrxTab(
                            hardwareInfo = hardwareInfo,
                            isVpnActive = isVpnActive,
                            vpnStatusLog = vpnStatusLog,
                            onToggleVpn = handleToggleVpn,
                            shizukuConnected = shizukuConnected,
                            shizukuPermissionGranted = shizukuPermissionGranted,
                            fangrxshotActive = fangrxshotActive,
                            fangrxshotRunning = fangrxshotRunning,
                            fangrxshotSucceededCount = fangrxshotSucceededCount,
                            fangrxshotLogs = fangrxshotLogs,
                            onToggleFangrxshot = viewModel::toggleFangrxshot,
                            packExportState = packExportState,
                            onExportPack = viewModel::generateOptimizationPack,
                            onOpenDownloads = viewModel::openDownloadsFolder
                        )
                    }

                    GrxTab.GERAR_SENSI -> {
                        GerarSensiTab(
                            hardwareInfo = hardwareInfo,
                            selectedBrand = selectedBrand,
                            onSelectBrand = viewModel::selectBrand,
                            selectedPlayStyle = selectedPlayStyle,
                            onSelectPlayStyle = viewModel::selectPlayStyle,
                            aiState = sensitivityAiState,
                            onGenerateAiSensitivity = viewModel::generateAiSensitivity,
                            onNavigateBackHome = { viewModel.selectTab(GrxTab.PAINEL_GRX) }
                        )
                    }

                    GrxTab.CRIADOR_RAYLAN -> {
                        CriadorRaylanTab(
                            tamperResult = tamperResult,
                            hardwareInfo = hardwareInfo,
                            isVpnActive = isVpnActive,
                            shizukuConnected = shizukuConnected,
                            onNavigateBackHome = { viewModel.selectTab(GrxTab.PAINEL_GRX) }
                        )
                    }
                }
            }
        }
    }
}
