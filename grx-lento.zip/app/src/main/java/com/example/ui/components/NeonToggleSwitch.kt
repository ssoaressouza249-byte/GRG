package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GrxBgDeep
import com.example.ui.theme.GrxCardElevated
import com.example.ui.theme.GrxElectricBlue
import com.example.ui.theme.GrxIceGray
import com.example.ui.theme.GrxNeonCyan
import com.example.ui.theme.GrxWhite

@Composable
fun ConsoleNeonToggleSwitch(
    isOn: Boolean,
    onToggle: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier,
    isBusy: Boolean = false
) {
    val borderColor by animateColorAsState(
        targetValue = if (isOn) GrxNeonCyan else GrxElectricBlue.copy(alpha = 0.55f),
        label = "toggle_border"
    )

    val trackColor by animateColorAsState(
        targetValue = if (isOn) Color(0xFF072338) else Color(0xFF060A13),
        label = "toggle_track"
    )

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .height(62.dp)
            .minimumInteractiveComponentSize()
            .testTag(testTag)
            .clip(RoundedCornerShape(16.dp))
            .background(trackColor)
            .border(1.5.dp, borderColor, RoundedCornerShape(16.dp))
            .clickable(enabled = !isBusy, onClick = onToggle)
            .padding(5.dp)
    ) {
        val totalTrackWidth = maxWidth
        val thumbWidth = totalTrackWidth * 0.52f
        val thumbOffset by animateDpAsState(
            targetValue = if (isOn) totalTrackWidth - thumbWidth else 0.dp,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessMedium
            ),
            label = "thumb_offset"
        )

        // Background labels OFF / ON
        Row(
            modifier = Modifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "OFF",
                    style = MaterialTheme.typography.labelLarge.copy(
                        color = if (!isOn) GrxIceGray else GrxIceGray.copy(alpha = 0.35f),
                        fontSize = 13.sp,
                        letterSpacing = 2.sp
                    )
                )
            }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "ON",
                    style = MaterialTheme.typography.labelLarge.copy(
                        color = if (isOn) GrxNeonCyan else GrxIceGray.copy(alpha = 0.35f),
                        fontSize = 13.sp,
                        letterSpacing = 2.sp
                    )
                )
            }
        }

        // Sliding mechanical neon console thumb
        Box(
            modifier = Modifier
                .offset(x = thumbOffset)
                .width(thumbWidth)
                .fillMaxHeight()
                .clip(RoundedCornerShape(12.dp))
                .background(
                    if (isOn) {
                        Brush.horizontalGradient(
                            colors = listOf(GrxElectricBlue, GrxNeonCyan)
                        )
                    } else {
                        Brush.horizontalGradient(
                            colors = listOf(Color(0xFF131D33), GrxCardElevated)
                        )
                    }
                )
                .border(
                    width = 1.dp,
                    color = if (isOn) GrxWhite.copy(alpha = 0.65f) else GrxElectricBlue.copy(alpha = 0.45f),
                    shape = RoundedCornerShape(12.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.PowerSettingsNew,
                    contentDescription = if (isOn) "Ligado" else "Desligado",
                    tint = if (isOn) GrxBgDeep else GrxIceGray,
                    modifier = Modifier.size(22.dp)
                )
                Text(
                    text = when {
                        isBusy -> "APLICANDO..."
                        isOn -> "ATIVADO"
                        else -> "DESATIVADO"
                    },
                    style = MaterialTheme.typography.labelLarge.copy(
                        color = if (isOn) GrxBgDeep else GrxWhite,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 12.sp
                    )
                )
            }
        }
    }
}
