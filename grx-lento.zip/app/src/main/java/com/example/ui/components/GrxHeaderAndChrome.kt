package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.GrxBgDeep
import com.example.ui.theme.GrxCardDark
import com.example.ui.theme.GrxCardElevated
import com.example.ui.theme.GrxElectricBlue
import com.example.ui.theme.GrxFooterBg
import com.example.ui.theme.GrxIceGray
import com.example.ui.theme.GrxNeonCyan
import com.example.ui.theme.GrxWhite

enum class GrxTab(val label: String, val testTag: String) {
    PAINEL_GRX("PAINEL GRX", "tab_painel_grx"),
    GERAR_SENSI("GERAR SENSI", "tab_gerar_sensi"),
    CRIADOR_RAYLAN("CRIADOR RAYLAN", "tab_criador_raylan")
}

@Composable
fun GrxTopHeader(
    selectedTab: GrxTab,
    onSelectTab: (GrxTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF060B16), GrxBgDeep.copy(alpha = 0.96f))
                )
            )
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                GrxVectorLogo(modifier = Modifier.size(42.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = stringResource(R.string.app_name),
                        style = MaterialTheme.typography.headlineMedium.copy(
                            color = GrxWhite,
                            fontWeight = FontWeight.ExtraBold
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = stringResource(R.string.app_subtitle),
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = GrxNeonCyan,
                            fontSize = 9.5.sp,
                            letterSpacing = 0.5.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(GrxElectricBlue.copy(alpha = 0.35f), GrxNeonCyan.copy(alpha = 0.22f))
                        )
                    )
                    .border(1.2.dp, GrxNeonCyan, RoundedCornerShape(50))
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Text(
                    text = stringResource(R.string.creator_badge),
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = GrxWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.5.sp
                    )
                )
            }
        }

        // Pill / Segmented Control Neon - Exatamente 3 Abas
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(50))
                .background(GrxCardDark)
                .border(1.5.dp, GrxElectricBlue.copy(alpha = 0.7f), RoundedCornerShape(50))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            GrxTab.entries.forEach { tab ->
                val isSelected = tab == selectedTab
                val textColor by animateColorAsState(
                    targetValue = if (isSelected) GrxBgDeep else GrxIceGray,
                    label = "tab_text_color"
                )
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag(tab.testTag)
                        .clip(RoundedCornerShape(50))
                        .background(
                            if (isSelected) {
                                Brush.horizontalGradient(
                                    colors = listOf(GrxNeonCyan, GrxElectricBlue)
                                )
                            } else {
                                Brush.horizontalGradient(
                                    colors = listOf(Color.Transparent, Color.Transparent)
                                )
                            }
                        )
                        .clickable { onSelectTab(tab) }
                        .padding(vertical = 10.dp, horizontal = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = tab.label,
                        style = MaterialTheme.typography.labelLarge.copy(
                            color = textColor,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 0.6.sp
                        ),
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
fun GrxVectorLogo(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Shield hexagon frame
        val shield = Path().apply {
            moveTo(w * 0.5f, h * 0.05f)
            lineTo(w * 0.92f, h * 0.25f)
            lineTo(w * 0.84f, h * 0.74f)
            lineTo(w * 0.5f, h * 0.95f)
            lineTo(w * 0.16f, h * 0.74f)
            lineTo(w * 0.08f, h * 0.25f)
            close()
        }
        drawPath(path = shield, color = GrxCardElevated)
        drawPath(
            path = shield,
            color = GrxNeonCyan,
            style = Stroke(width = w * 0.06f, join = StrokeJoin.Round)
        )

        // Center electric bolt
        val bolt = Path().apply {
            moveTo(w * 0.56f, h * 0.18f)
            lineTo(w * 0.34f, h * 0.53f)
            lineTo(w * 0.51f, h * 0.53f)
            lineTo(w * 0.43f, h * 0.82f)
            lineTo(w * 0.68f, h * 0.45f)
            lineTo(w * 0.50f, h * 0.45f)
            close()
        }
        drawPath(path = bolt, color = GrxElectricBlue)
        drawPath(
            path = bolt,
            color = GrxNeonCyan,
            style = Stroke(width = w * 0.04f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}

@Composable
fun GrxMandatoryFooter(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(GrxFooterBg)
            .navigationBarsPadding()
    ) {
        HorizontalDivider(
            thickness = 1.5.dp,
            color = GrxNeonCyan.copy(alpha = 0.85f)
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp, horizontal = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = stringResource(R.string.footer_signature),
                style = MaterialTheme.typography.labelLarge.copy(
                    color = GrxNeonCyan,
                    fontSize = 11.sp,
                    letterSpacing = 1.6.sp
                ),
                textAlign = TextAlign.Center
            )
        }
    }
}
