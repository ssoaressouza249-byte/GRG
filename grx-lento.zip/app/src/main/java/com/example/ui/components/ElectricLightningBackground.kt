package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.ui.theme.GrxBgDeep
import com.example.ui.theme.GrxElectricBlue
import com.example.ui.theme.GrxNeonCyan

@Composable
fun ElectricLightningBackground(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val transition = rememberInfiniteTransition(label = "lightning_pulse")
    val pulse by transition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.72f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(GrxBgDeep)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Subtle ambient electric blue glow top & bottom
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        GrxElectricBlue.copy(alpha = 0.16f * pulse),
                        GrxBgDeep.copy(alpha = 0f)
                    ),
                    center = Offset(w * 0.5f, h * 0.08f),
                    radius = w * 0.85f
                ),
                radius = w * 0.85f,
                center = Offset(w * 0.5f, h * 0.08f)
            )

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        GrxNeonCyan.copy(alpha = 0.08f * pulse),
                        GrxBgDeep.copy(alpha = 0f)
                    ),
                    center = Offset(w * 0.85f, h * 0.82f),
                    radius = w * 0.65f
                ),
                radius = w * 0.65f,
                center = Offset(w * 0.85f, h * 0.82f)
            )

            // Top-left electric lightning bolt
            val topLeftBolt = Path().apply {
                moveTo(0f, h * 0.09f)
                lineTo(w * 0.12f, h * 0.12f)
                lineTo(w * 0.08f, h * 0.17f)
                lineTo(w * 0.21f, h * 0.21f)
                lineTo(w * 0.15f, h * 0.25f)
            }
            drawPath(
                path = topLeftBolt,
                color = GrxElectricBlue.copy(alpha = 0.35f * pulse),
                style = Stroke(width = 7f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
            drawPath(
                path = topLeftBolt,
                color = GrxNeonCyan.copy(alpha = 0.55f * pulse),
                style = Stroke(width = 2.2f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )

            // Top-right electric lightning bolt
            val topRightBolt = Path().apply {
                moveTo(w, h * 0.14f)
                lineTo(w * 0.87f, h * 0.17f)
                lineTo(w * 0.91f, h * 0.22f)
                lineTo(w * 0.77f, h * 0.27f)
            }
            drawPath(
                path = topRightBolt,
                color = GrxElectricBlue.copy(alpha = 0.30f * pulse),
                style = Stroke(width = 7f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
            drawPath(
                path = topRightBolt,
                color = GrxNeonCyan.copy(alpha = 0.50f * pulse),
                style = Stroke(width = 2f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )

            // Mid-left jagged arc
            val midLeftBolt = Path().apply {
                moveTo(0f, h * 0.54f)
                lineTo(w * 0.09f, h * 0.57f)
                lineTo(w * 0.05f, h * 0.61f)
                lineTo(w * 0.14f, h * 0.65f)
            }
            drawPath(
                path = midLeftBolt,
                color = GrxNeonCyan.copy(alpha = 0.28f * pulse),
                style = Stroke(width = 2.5f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )

            // Bottom-right electric lightning bolt
            val bottomRightBolt = Path().apply {
                moveTo(w, h * 0.78f)
                lineTo(w * 0.86f, h * 0.82f)
                lineTo(w * 0.90f, h * 0.87f)
                lineTo(w * 0.74f, h * 0.92f)
            }
            drawPath(
                path = bottomRightBolt,
                color = GrxElectricBlue.copy(alpha = 0.35f * pulse),
                style = Stroke(width = 6.5f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
            drawPath(
                path = bottomRightBolt,
                color = GrxNeonCyan.copy(alpha = 0.52f * pulse),
                style = Stroke(width = 2f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
        }

        content()
    }
}
