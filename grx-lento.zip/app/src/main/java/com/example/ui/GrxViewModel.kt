package com.example.ui

import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.SensitivityAiRepository
import com.example.ai.SensitivityProfile
import com.example.export.ExportedPackResult
import com.example.export.PackExporter
import com.example.hardware.DeviceHardwareInfo
import com.example.hardware.DeviceTelemetryReader
import com.example.hardware.PhoneBrand
import com.example.hardware.PlayStyle
import com.example.security.SecurityGuard
import com.example.security.TamperCheckResult
import com.example.shizuku.FangrxshotManager
import com.example.ui.components.GrxTab
import com.example.vpn.GrxGamingVpnService
import com.example.vpn.VpnStateHolder
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

sealed interface PackExportUiState {
    data object Idle : PackExportUiState
    data object Exporting : PackExportUiState
    data class Exported(val result: ExportedPackResult) : PackExportUiState
    data class Error(val message: String) : PackExportUiState
}

sealed interface SensitivityAiUiState {
    data object Idle : SensitivityAiUiState
    data object Loading : SensitivityAiUiState
    data class Success(val profile: SensitivityProfile) : SensitivityAiUiState
    data class Error(val message: String) : SensitivityAiUiState
}

class GrxViewModel(application: Application) : AndroidViewModel(application) {

    private val aiRepository = SensitivityAiRepository()

    private val _selectedTab = MutableStateFlow(GrxTab.PAINEL_GRX)
    val selectedTab: StateFlow<GrxTab> = _selectedTab.asStateFlow()

    private val _tamperResult = MutableStateFlow(SecurityGuard.verify(application))
    val tamperResult: StateFlow<TamperCheckResult> = _tamperResult.asStateFlow()

    private val _hardwareInfo = MutableStateFlow(DeviceTelemetryReader.read(application))
    val hardwareInfo: StateFlow<DeviceHardwareInfo> = _hardwareInfo.asStateFlow()

    val isVpnActive: StateFlow<Boolean> = VpnStateHolder.isVpnActive
    val vpnStatusLog: StateFlow<String> = VpnStateHolder.statusLog

    private val _shizukuConnected = MutableStateFlow(FangrxshotManager.isShizukuAvailable())
    val shizukuConnected: StateFlow<Boolean> = _shizukuConnected.asStateFlow()

    private val _shizukuPermissionGranted = MutableStateFlow(FangrxshotManager.hasShizukuPermission())
    val shizukuPermissionGranted: StateFlow<Boolean> = _shizukuPermissionGranted.asStateFlow()

    private val _shizukuAppInstalled = MutableStateFlow(FangrxshotManager.isShizukuAppInstalled(application))
    val shizukuAppInstalled: StateFlow<Boolean> = _shizukuAppInstalled.asStateFlow()

    private val _fangrxshotActive = MutableStateFlow(false)
    val fangrxshotActive: StateFlow<Boolean> = _fangrxshotActive.asStateFlow()

    private val _fangrxshotRunning = MutableStateFlow(false)
    val fangrxshotRunning: StateFlow<Boolean> = _fangrxshotRunning.asStateFlow()

    private val _fangrxshotSucceededCount = MutableStateFlow(0)
    val fangrxshotSucceededCount: StateFlow<Int> = _fangrxshotSucceededCount.asStateFlow()

    private val _fangrxshotLogs = MutableStateFlow<List<String>>(
        listOf("Pronto para injetar ${FangrxshotManager.COMMANDS.size} otimizações FANGRXSHOT via Shizuku.")
    )
    val fangrxshotLogs: StateFlow<List<String>> = _fangrxshotLogs.asStateFlow()

    private val _packExportState = MutableStateFlow<PackExportUiState>(PackExportUiState.Idle)
    val packExportState: StateFlow<PackExportUiState> = _packExportState.asStateFlow()

    private val _selectedBrand = MutableStateFlow(_hardwareInfo.value.detectedBrand)
    val selectedBrand: StateFlow<PhoneBrand> = _selectedBrand.asStateFlow()

    private val _selectedPlayStyle = MutableStateFlow(PlayStyle.BONECO_LENTO)
    val selectedPlayStyle: StateFlow<PlayStyle> = _selectedPlayStyle.asStateFlow()

    private val _sensitivityAiState = MutableStateFlow<SensitivityAiUiState>(SensitivityAiUiState.Idle)
    val sensitivityAiState: StateFlow<SensitivityAiUiState> = _sensitivityAiState.asStateFlow()

    private var lastGeneratedSensitivity: SensitivityProfile? = null
    private var pendingFangrxshotAfterPermission = false

    fun selectTab(tab: GrxTab) {
        _selectedTab.value = tab
    }

    fun refreshSecurityAndHardware() {
        val app = getApplication<Application>()
        _tamperResult.value = SecurityGuard.verify(app)
        _hardwareInfo.value = DeviceTelemetryReader.read(app)
        refreshShizukuStatus()
    }

    fun refreshShizukuStatus() {
        val app = getApplication<Application>()
        _shizukuAppInstalled.value = FangrxshotManager.isShizukuAppInstalled(app)
        val connected = FangrxshotManager.isShizukuAvailable()
        _shizukuConnected.value = connected
        _shizukuPermissionGranted.value = if (connected) {
            FangrxshotManager.hasShizukuPermission()
        } else {
            false
        }
    }

    fun onShizukuPermissionResult(requestCode: Int, grantResult: Int) {
        if (requestCode == FangrxshotManager.SHIZUKU_PERMISSION_REQUEST_CODE) {
            val granted = grantResult == PackageManager.PERMISSION_GRANTED
            _shizukuPermissionGranted.value = granted
            if (granted && pendingFangrxshotAfterPermission) {
                pendingFangrxshotAfterPermission = false
                executeFangrxshotCommands()
            } else if (!granted) {
                pendingFangrxshotAfterPermission = false
                _fangrxshotLogs.value = _fangrxshotLogs.value +
                    "[AVISO] Permissão Shizuku negada pelo usuário."
            }
        }
    }

    fun startVpnService() {
        val app = getApplication<Application>()
        val integrity = SecurityGuard.verify(app)
        _tamperResult.value = integrity
        if (integrity !is TamperCheckResult.Verified) return

        val intent = Intent(app, GrxGamingVpnService::class.java).apply {
            action = GrxGamingVpnService.ACTION_START
        }
        ContextCompat.startForegroundService(app, intent)
    }

    fun stopVpnService() {
        val app = getApplication<Application>()
        val intent = Intent(app, GrxGamingVpnService::class.java).apply {
            action = GrxGamingVpnService.ACTION_STOP
        }
        app.startService(intent)
    }

    fun prepareVpnIntent(): Intent? {
        val app = getApplication<Application>()
        return VpnService.prepare(app)
    }

    fun toggleFangrxshot() {
        val app = getApplication<Application>()
        val integrity = SecurityGuard.verify(app)
        _tamperResult.value = integrity
        if (integrity !is TamperCheckResult.Verified) return

        if (_fangrxshotRunning.value) return

        if (_fangrxshotActive.value) {
            _fangrxshotActive.value = false
            _fangrxshotSucceededCount.value = 0
            _fangrxshotLogs.value = listOf("Modo FANGRXSHOT desativado pelo usuário.")
            return
        }

        refreshShizukuStatus()

        if (!_shizukuConnected.value) {
            _fangrxshotLogs.value = listOf(
                "[AGUARDANDO] Serviço Shizuku não está conectado.",
                "Abra o app Shizuku, inicie via Depuração Sem Fio (ADB) ou Root e tente novamente."
            )
            return
        }

        if (!_shizukuPermissionGranted.value) {
            pendingFangrxshotAfterPermission = true
            _fangrxshotLogs.value = listOf("[PERMISSÃO] Solicitando autorização ao Shizuku...")
            runCatching {
                Shizuku.requestPermission(FangrxshotManager.SHIZUKU_PERMISSION_REQUEST_CODE)
            }.onFailure { err ->
                pendingFangrxshotAfterPermission = false
                _fangrxshotLogs.value = listOf(
                    "[ERRO] Falha ao solicitar permissão Shizuku: ${err.localizedMessage ?: "desconhecido"}"
                )
            }
            return
        }

        executeFangrxshotCommands()
    }

    private fun executeFangrxshotCommands() {
        val app = getApplication<Application>()
        viewModelScope.launch {
            _fangrxshotRunning.value = true
            _fangrxshotSucceededCount.value = 0
            val liveLogs = mutableListOf("Iniciando injeção FANGRXSHOT via Shizuku (${FangrxshotManager.COMMANDS.size} comandos)...")
            _fangrxshotLogs.value = liveLogs.toList()

            val summary = FangrxshotManager.executeAllCommands(app) { _, _, logLine ->
                liveLogs.add(logLine)
                _fangrxshotLogs.value = liveLogs.toList()
            }

            _fangrxshotSucceededCount.value = summary.succeededCount
            _fangrxshotActive.value = true
            _fangrxshotRunning.value = false
        }
    }

    fun generateOptimizationPack() {
        val app = getApplication<Application>()
        val integrity = SecurityGuard.verify(app)
        _tamperResult.value = integrity
        if (integrity !is TamperCheckResult.Verified) return

        viewModelScope.launch {
            _packExportState.value = PackExportUiState.Exporting
            val result = PackExporter.exportOptimizationPack(
                context = app,
                hardware = _hardwareInfo.value,
                sensitivity = lastGeneratedSensitivity
            )
            _packExportState.value = result.fold(
                onSuccess = { PackExportUiState.Exported(it) },
                onFailure = {
                    PackExportUiState.Error(
                        it.localizedMessage ?: "Falha ao salvar pack na pasta Download."
                    )
                }
            )
        }
    }

    fun openDownloadsFolder() {
        PackExporter.openDownloadsFolder(getApplication())
    }

    fun selectBrand(brand: PhoneBrand) {
        _selectedBrand.value = brand
    }

    fun selectPlayStyle(playStyle: PlayStyle) {
        _selectedPlayStyle.value = playStyle
    }

    fun generateAiSensitivity() {
        val app = getApplication<Application>()
        val integrity = SecurityGuard.verify(app)
        _tamperResult.value = integrity
        if (integrity !is TamperCheckResult.Verified) return

        viewModelScope.launch {
            _sensitivityAiState.value = SensitivityAiUiState.Loading
            try {
                val profile = aiRepository.generateSensitivity(
                    brand = _selectedBrand.value,
                    playstyle = _selectedPlayStyle.value,
                    hardware = _hardwareInfo.value
                )
                lastGeneratedSensitivity = profile
                _sensitivityAiState.value = SensitivityAiUiState.Success(profile)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Erro ao gerar sensibilidade com IA", e)
                _sensitivityAiState.value = SensitivityAiUiState.Error(
                    e.localizedMessage ?: "Falha ao consultar o Sistema IA GRX."
                )
            }
        }
    }

    companion object {
        private const val TAG = "GrxViewModel"
    }
}
