package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val GrxBgDeep = Color(0xFF04060B)
val GrxCardDark = Color(0xFF090E1A)
val GrxCardElevated = Color(0xFF0D1526)
val GrxFooterBg = Color(0xFF060A13)

val GrxNeonCyan = Color(0xFF00E5FF)
val GrxElectricBlue = Color(0xFF0066FF)
val GrxRoyalBlue = Color(0xFF1D4ED8)

val GrxWhite = Color(0xFFFFFFFF)
val GrxIceGray = Color(0xFF94A3B8)
val GrxMutedSlate = Color(0xFF475569)

val GrxSuccessGreen = Color(0xFF00FFA3)
val GrxAlertRed = Color(0xFFFF1E42)
val GrxWarningAmber = Color(0xFFFFB020)
