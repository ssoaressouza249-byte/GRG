package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material.icons.rounded.VpnLock
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.hardware.DeviceHardwareInfo
import com.example.security.TamperCheckResult
import com.example.ui.theme.GrxCardDark
import com.example.ui.theme.GrxCardElevated
import com.example.ui.theme.GrxElectricBlue
import com.example.ui.theme.GrxIceGray
import com.example.ui.theme.GrxNeonCyan
import com.example.ui.theme.GrxSuccessGreen
import com.example.ui.theme.GrxWhite

@Composable
fun CriadorRaylanTab(
    tamperResult: TamperCheckResult,
    hardwareInfo: DeviceHardwareInfo,
    isVpnActive: Boolean,
    shizukuConnected: Boolean,
    onNavigateBackHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onNavigateBackHome)

    val scrollState = rememberScrollState()

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxWidth()
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Card Perfil Oficial do Criador RAYLAN GRX
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color(0xFF0A1730), GrxCardDark)
                        )
                    )
                    .border(1.5.dp, GrxNeonCyan, RoundedCornerShape(22.dp))
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                RaylanCrestEmblem(modifier = Modifier.size(92.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "RAYLAN GRX",
                        style = MaterialTheme.typography.headlineLarge.copy(
                            color = GrxWhite,
                            fontSize = 22.sp
                        )
                    )
                    Icon(
                        imageVector = Icons.Rounded.Verified,
                        contentDescription = "Criador Verificado",
                        tint = GrxNeonCyan,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(GrxElectricBlue.copy(alpha = 0.25f))
                        .border(1.dp, GrxNeonCyan, RoundedCornerShape(50))
                        .padding(horizontal = 14.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = "CRIADOR OFICIAL • GRX LENTO",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = GrxNeonCyan,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                Text(
                    text = "Desenvolvedor e idealizador do ecossistema GRX LENTO, combinando túnel VPN local de baixa latência, motor tátil FANGRXSHOT via Shizuku e calibração inteligente com Sistema IA GRX.",
                    style = MaterialTheme.typography.bodyLarge.copy(color = GrxIceGray),
                    textAlign = TextAlign.Center
                )
            }

            // Card Arquitetura do Ecossistema
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(GrxCardDark)
                    .border(1.5.dp, GrxElectricBlue, RoundedCornerShape(20.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "ARQUITETURA DO ECOSSISTEMA",
                    style = MaterialTheme.typography.titleLarge.copy(
                        color = GrxWhite,
                        fontSize = 13.5.sp
                    )
                )

                CreatorFeatureRow(
                    icon = Icons.Rounded.VpnLock,
                    title = "Modo Boneco Lento + VPN Boost",
                    desc = "Interface VPN local com DNS 1.1.1.1 / 8.8.8.8 e MTU 1400 para estabilidade de rede sem retenção de tráfego."
                )
                CreatorFeatureRow(
                    icon = Icons.Rounded.Bolt,
                    title = "Motor FANGRXSHOT (Shizuku)",
                    desc = "Execução individual de 50 comandos ADB/System para resposta tátil, renderização Vulkan e redução de latência."
                )
                CreatorFeatureRow(
                    icon = Icons.Rounded.Code,
                    title = "Sistema IA GRX & Exportação ZIP",
                    desc = "Calibração por marca/hardware e geração direta de packs oficiais na pasta pública Download."
                )
            }

            // Card Integridade Criptográfica e Segurança Anti-MT Manager
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(GrxCardDark)
                    .border(1.5.dp, GrxNeonCyan, RoundedCornerShape(20.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Security,
                        contentDescription = "SecurityGuard",
                        tint = GrxSuccessGreen,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "INTEGRIDADE & AUTENTICIDADE",
                        style = MaterialTheme.typography.titleLarge.copy(
                            color = GrxWhite,
                            fontSize = 13.5.sp
                        )
                    )
                }

                if (tamperResult is TamperCheckResult.Verified) {
                    IntegrityRow(label = "App Original", value = "${tamperResult.appLabel} ✓")
                    IntegrityRow(label = "Pacote Oficial", value = "${tamperResult.packageName} ✓")
                    IntegrityRow(label = "Selo SHA-256 Autor", value = "RAYLAN GRX AUTÊNTICO ✓")
                }

                IntegrityRow(
                    label = "VPN Local",
                    value = if (isVpnActive) "ATIVA (DNS 1.1.1.1 / MTU 1400)" else "Em espera"
                )
                IntegrityRow(
                    label = "Shizuku Binder",
                    value = if (shizukuConnected) "CONECTADO" else "Aguardando serviço"
                )
                IntegrityRow(
                    label = "Hardware Atual",
                    value = "${hardwareInfo.modelName} (${hardwareInfo.refreshRateHz}Hz)"
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
        }
    }
}

@Composable
private fun RaylanCrestEmblem(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(CircleShape)
            .background(Color(0xFF061022))
            .border(2.dp, GrxNeonCyan, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize().padding(14.dp)) {
            val w = size.width
            val h = size.height

            drawCircle(
                color = GrxElectricBlue.copy(alpha = 0.22f),
                radius = w * 0.48f,
                center = Offset(w * 0.5f, h * 0.5f)
            )

            val crestBolt = Path().apply {
                moveTo(w * 0.56f, h * 0.08f)
                lineTo(w * 0.26f, h * 0.54f)
                lineTo(w * 0.48f, h * 0.54f)
                lineTo(w * 0.38f, h * 0.92f)
                lineTo(w * 0.74f, h * 0.44f)
                lineTo(w * 0.52f, h * 0.44f)
                close()
            }
            drawPath(path = crestBolt, color = GrxElectricBlue)
            drawPath(
                path = crestBolt,
                color = GrxNeonCyan,
                style = Stroke(width = 3.5f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
        }
    }
}

@Composable
private fun CreatorFeatureRow(
    icon: ImageVector,
    title: String,
    desc: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(GrxCardElevated)
            .border(1.dp, GrxElectricBlue.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
            .padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(GrxNeonCyan.copy(alpha = 0.14f))
                .border(1.dp, GrxNeonCyan.copy(alpha = 0.7f), RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = GrxNeonCyan,
                modifier = Modifier.size(20.dp)
            )
        }
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(color = GrxWhite)
            )
            Text(
                text = desc,
                style = MaterialTheme.typography.bodyMedium.copy(color = GrxIceGray)
            )
        }
    }
}

@Composable
private fun IntegrityRow(
    label: String,
    value: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(GrxCardElevated)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(color = GrxIceGray)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelSmall.copy(
                color = GrxNeonCyan,
                fontWeight = FontWeight.Bold
            )
        )
    }
}
