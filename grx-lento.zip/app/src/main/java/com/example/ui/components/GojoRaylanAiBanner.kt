package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GrxBgDeep
import com.example.ui.theme.GrxCardDark
import com.example.ui.theme.GrxCardElevated
import com.example.ui.theme.GrxElectricBlue
import com.example.ui.theme.GrxNeonCyan
import com.example.ui.theme.GrxSuccessGreen
import com.example.ui.theme.GrxWhite
import com.example.ui.theme.OrbitronFontFamily

@Composable
fun GojoRaylanAiBanner(
    modifier: Modifier = Modifier,
    compact: Boolean = false
) {
    val transition = rememberInfiniteTransition(label = "gojo_energy")
    val energyGlow by transition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "energy_glow"
    )

    val textMeasurer = rememberTextMeasurer()
    val bannerHeight = if (compact) 168.dp else 218.dp

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF071124), GrxCardDark)
                )
            )
            .border(1.5.dp, GrxNeonCyan, RoundedCornerShape(18.dp))
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(bannerHeight)
        ) {
            val w = size.width
            val h = size.height
            val cx = w * 0.5f

            // Background cyber radial aura behind character
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        GrxNeonCyan.copy(alpha = 0.28f * energyGlow),
                        GrxElectricBlue.copy(alpha = 0.14f * energyGlow),
                        Color.Transparent
                    ),
                    center = Offset(cx, h * 0.42f),
                    radius = h * 0.72f
                ),
                radius = h * 0.72f,
                center = Offset(cx, h * 0.42f)
            )

            // Tech halo ring behind head
            drawCircle(
                color = GrxNeonCyan.copy(alpha = 0.22f * energyGlow),
                radius = h * 0.34f,
                center = Offset(cx, h * 0.36f),
                style = Stroke(width = 2f)
            )
            drawCircle(
                color = GrxElectricBlue.copy(alpha = 0.35f),
                radius = h * 0.40f,
                center = Offset(cx, h * 0.36f),
                style = Stroke(width = 1.5f)
            )

            // Crackling electric lightning bolts around character
            val leftBolt = Path().apply {
                moveTo(w * 0.14f, h * 0.20f)
                lineTo(w * 0.24f, h * 0.29f)
                lineTo(w * 0.19f, h * 0.37f)
                lineTo(w * 0.29f, h * 0.48f)
            }
            val rightBolt = Path().apply {
                moveTo(w * 0.86f, h * 0.18f)
                lineTo(w * 0.76f, h * 0.28f)
                lineTo(w * 0.81f, h * 0.36f)
                lineTo(w * 0.71f, h * 0.48f)
            }
            val topLeftArc = Path().apply {
                moveTo(w * 0.06f, h * 0.56f)
                lineTo(w * 0.16f, h * 0.52f)
                lineTo(w * 0.12f, h * 0.62f)
                lineTo(w * 0.22f, h * 0.60f)
            }
            val topRightArc = Path().apply {
                moveTo(w * 0.94f, h * 0.56f)
                lineTo(w * 0.84f, h * 0.52f)
                lineTo(w * 0.88f, h * 0.62f)
                lineTo(w * 0.78f, h * 0.60f)
            }

            listOf(leftBolt, rightBolt, topLeftArc, topRightArc).forEach { bolt ->
                drawPath(
                    path = bolt,
                    color = GrxElectricBlue.copy(alpha = 0.55f * energyGlow),
                    style = Stroke(width = 7f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
                drawPath(
                    path = bolt,
                    color = GrxNeonCyan.copy(alpha = 0.95f * energyGlow),
                    style = Stroke(width = 2.4f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
            }

            // High-collar cyber jacket / shoulders bust
            val jacketPath = Path().apply {
                moveTo(cx - h * 0.36f, h * 0.92f)
                lineTo(cx - h * 0.30f, h * 0.60f)
                lineTo(cx - h * 0.15f, h * 0.53f)
                lineTo(cx - h * 0.12f, h * 0.43f)
                lineTo(cx + h * 0.12f, h * 0.43f)
                lineTo(cx + h * 0.15f, h * 0.53f)
                lineTo(cx + h * 0.30f, h * 0.60f)
                lineTo(cx + h * 0.36f, h * 0.92f)
                close()
            }
            drawPath(
                path = jacketPath,
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF0B1426), Color(0xFF04070E))
                )
            )
            drawPath(
                path = jacketPath,
                color = GrxElectricBlue.copy(alpha = 0.85f),
                style = Stroke(width = 2.6f, join = StrokeJoin.Round)
            )

            // Neck & Chin / Lower Face
            val facePath = Path().apply {
                moveTo(cx - h * 0.11f, h * 0.30f)
                lineTo(cx - h * 0.11f, h * 0.41f)
                quadraticTo(cx, h * 0.51f, cx + h * 0.11f, h * 0.41f)
                lineTo(cx + h * 0.11f, h * 0.30f)
                close()
            }
            drawPath(
                path = facePath,
                color = Color(0xFFE7EEF8)
            )
            // Subtle confident smirk
            val smirkPath = Path().apply {
                moveTo(cx - h * 0.035f, h * 0.425f)
                quadraticTo(cx, h * 0.44f, cx + h * 0.042f, h * 0.418f)
            }
            drawPath(
                path = smirkPath,
                color = Color(0xFF1E293B),
                style = Stroke(width = 2f, cap = StrokeCap.Round)
            )

            // Black Blindfold across the eyes with Neon Blue Energy Glow
            val blindfoldRectTop = h * 0.255f
            val blindfoldHeight = h * 0.115f
            val blindfoldLeft = cx - h * 0.125f
            val blindfoldWidth = h * 0.25f

            // Glowing blue energy behind/around blindfold (Six Eyes aura)
            drawRoundRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        Color.Transparent,
                        GrxNeonCyan.copy(alpha = 0.85f * energyGlow),
                        GrxElectricBlue.copy(alpha = 0.9f * energyGlow),
                        GrxNeonCyan.copy(alpha = 0.85f * energyGlow),
                        Color.Transparent
                    )
                ),
                topLeft = Offset(blindfoldLeft - h * 0.05f, blindfoldRectTop - 3f),
                size = Size(blindfoldWidth + h * 0.10f, blindfoldHeight + 6f),
                cornerRadius = CornerRadius(12f, 12f)
            )

            // Solid black blindfold band
            drawRoundRect(
                color = Color(0xFF05070D),
                topLeft = Offset(blindfoldLeft, blindfoldRectTop),
                size = Size(blindfoldWidth, blindfoldHeight),
                cornerRadius = CornerRadius(8f, 8f)
            )
            drawRoundRect(
                color = GrxNeonCyan.copy(alpha = 0.85f),
                topLeft = Offset(blindfoldLeft, blindfoldRectTop),
                size = Size(blindfoldWidth, blindfoldHeight),
                cornerRadius = CornerRadius(8f, 8f),
                style = Stroke(width = 1.6f)
            )

            // Glowing neon blue eye energy slits shining through the blindfold
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.White, GrxNeonCyan, Color.Transparent),
                    center = Offset(cx - h * 0.052f, blindfoldRectTop + blindfoldHeight * 0.52f),
                    radius = h * 0.048f
                ),
                radius = h * 0.048f,
                center = Offset(cx - h * 0.052f, blindfoldRectTop + blindfoldHeight * 0.52f)
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.White, GrxNeonCyan, Color.Transparent),
                    center = Offset(cx + h * 0.052f, blindfoldRectTop + blindfoldHeight * 0.52f),
                    radius = h * 0.048f
                ),
                radius = h * 0.048f,
                center = Offset(cx + h * 0.052f, blindfoldRectTop + blindfoldHeight * 0.52f)
            )

            // Spiky White Anime Hair (Gojo-style)
            val hairPath = Path().apply {
                moveTo(cx - h * 0.13f, h * 0.28f)
                lineTo(cx - h * 0.22f, h * 0.21f)
                lineTo(cx - h * 0.15f, h * 0.19f)
                lineTo(cx - h * 0.21f, h * 0.10f)
                lineTo(cx - h * 0.11f, h * 0.14f)
                lineTo(cx - h * 0.09f, h * 0.04f)
                lineTo(cx - h * 0.02f, h * 0.12f)
                lineTo(cx + h * 0.03f, h * 0.03f)
                lineTo(cx + h * 0.08f, h * 0.13f)
                lineTo(cx + h * 0.18f, h * 0.07f)
                lineTo(cx + h * 0.15f, h * 0.18f)
                lineTo(cx + h * 0.24f, h * 0.19f)
                lineTo(cx + h * 0.14f, h * 0.27f)
                // Bangs sweeping slightly over blindfold edge
                lineTo(cx + h * 0.08f, h * 0.24f)
                lineTo(cx + h * 0.02f, h * 0.28f)
                lineTo(cx - h * 0.03f, h * 0.23f)
                lineTo(cx - h * 0.08f, h * 0.28f)
                close()
            }
            drawPath(
                path = hairPath,
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFFFFFFFF), Color(0xFFD6EAFF))
                )
            )
            drawPath(
                path = hairPath,
                color = GrxNeonCyan.copy(alpha = 0.7f),
                style = Stroke(width = 1.8f, join = StrokeJoin.Round)
            )

            // Holographic Neon Blue Panel held in front displaying "RAYLAN"
            val panelW = (w * 0.56f).coerceAtMost(h * 1.45f)
            val panelH = h * 0.25f
            val panelLeft = cx - panelW / 2f
            val panelTop = h * 0.61f

            // Outer hologram glow
            drawRoundRect(
                color = GrxNeonCyan.copy(alpha = 0.20f * energyGlow),
                topLeft = Offset(panelLeft - 6f, panelTop - 6f),
                size = Size(panelW + 12f, panelH + 12f),
                cornerRadius = CornerRadius(18f, 18f)
            )

            // Hologram panel fill
            drawRoundRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        Color(0xE6051229),
                        Color(0xF00A2347),
                        Color(0xE6051229)
                    )
                ),
                topLeft = Offset(panelLeft, panelTop),
                size = Size(panelW, panelH),
                cornerRadius = CornerRadius(14f, 14f)
            )

            // Hologram double border
            drawRoundRect(
                color = GrxNeonCyan,
                topLeft = Offset(panelLeft, panelTop),
                size = Size(panelW, panelH),
                cornerRadius = CornerRadius(14f, 14f),
                style = Stroke(width = 2.6f)
            )

            // Stylized hands holding the holographic panel sides
            drawRoundRect(
                color = Color(0xFFE7EEF8),
                topLeft = Offset(panelLeft - h * 0.035f, panelTop + panelH * 0.22f),
                size = Size(h * 0.055f, panelH * 0.56f),
                cornerRadius = CornerRadius(10f, 10f)
            )
            drawRoundRect(
                color = Color(0xFFE7EEF8),
                topLeft = Offset(panelLeft + panelW - h * 0.02f, panelTop + panelH * 0.22f),
                size = Size(h * 0.055f, panelH * 0.56f),
                cornerRadius = CornerRadius(10f, 10f)
            )

            // Glowing "RAYLAN" text inside the holographic panel
            val raylanStyle = TextStyle(
                fontFamily = OrbitronFontFamily,
                fontWeight = FontWeight.ExtraBold,
                fontSize = if (compact) 17.sp else 21.sp,
                letterSpacing = 3.sp,
                color = GrxWhite
            )
            val measured = textMeasurer.measure("RAYLAN", style = raylanStyle)
            val textX = cx - measured.size.width / 2f
            val textY = panelTop + (panelH - measured.size.height) / 2f

            // Glow shadow pass
            drawText(
                textLayoutResult = textMeasurer.measure(
                    "RAYLAN",
                    style = raylanStyle.copy(color = GrxNeonCyan.copy(alpha = 0.85f * energyGlow))
                ),
                topLeft = Offset(textX + 1.5f, textY + 1.5f)
            )
            drawText(
                textLayoutResult = measured,
                topLeft = Offset(textX, textY)
            )
        }

        // Top-right Seal: SISTEMA IA GRX ATIVO
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(10.dp)
                .clip(RoundedCornerShape(50))
                .background(GrxBgDeep.copy(alpha = 0.88f))
                .border(1.dp, GrxNeonCyan, RoundedCornerShape(50))
                .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(GrxSuccessGreen)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "SISTEMA IA GRX ATIVO",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = GrxNeonCyan,
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.5.sp
                )
            )
        }

        // Bottom-left subtle neural badge
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(10.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(GrxCardElevated.copy(alpha = 0.8f))
                .border(1.dp, GrxElectricBlue.copy(alpha = 0.7f), RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
            Text(
                text = "GRX NEURAL v4",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = GrxWhite,
                    fontSize = 9.sp
                )
            )
        }
    }
}
