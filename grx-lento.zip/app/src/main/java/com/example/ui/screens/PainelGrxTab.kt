package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material.icons.rounded.VpnLock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.hardware.DeviceHardwareInfo
import com.example.shizuku.FangrxshotManager
import com.example.ui.PackExportUiState
import com.example.ui.components.ConsoleNeonToggleSwitch
import com.example.ui.components.GojoRaylanAiBanner
import com.example.ui.theme.GrxAlertRed
import com.example.ui.theme.GrxBgDeep
import com.example.ui.theme.GrxCardDark
import com.example.ui.theme.GrxCardElevated
import com.example.ui.theme.GrxElectricBlue
import com.example.ui.theme.GrxIceGray
import com.example.ui.theme.GrxNeonCyan
import com.example.ui.theme.GrxRoyalBlue
import com.example.ui.theme.GrxSuccessGreen
import com.example.ui.theme.GrxWarningAmber
import com.example.ui.theme.GrxWhite

@Composable
fun PainelGrxTab(
    hardwareInfo: DeviceHardwareInfo,
    isVpnActive: Boolean,
    vpnStatusLog: String,
    onToggleVpn: () -> Unit,
    shizukuConnected: Boolean,
    shizukuPermissionGranted: Boolean,
    fangrxshotActive: Boolean,
    fangrxshotRunning: Boolean,
    fangrxshotSucceededCount: Int,
    fangrxshotLogs: List<String>,
    onToggleFangrxshot: () -> Unit,
    packExportState: PackExportUiState,
    onExportPack: () -> Unit,
    onOpenDownloads: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val logListState = rememberLazyListState()

    LaunchedEffect(fangrxshotLogs.size) {
        if (fangrxshotLogs.isNotEmpty()) {
            logListState.animateScrollToItem(fangrxshotLogs.lastIndex)
        }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxWidth()
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Card Sistema IA (GojoRaylanAiBanner + Leitura Real de Hardware)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(GrxCardDark)
                    .border(1.5.dp, GrxNeonCyan, RoundedCornerShape(20.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                GojoRaylanAiBanner()

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Memory,
                        contentDescription = "Telemetria do aparelho",
                        tint = GrxNeonCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "TELEMETRIA REAL DO APARELHO",
                        style = MaterialTheme.typography.labelLarge.copy(
                            color = GrxWhite,
                            fontSize = 11.sp
                        )
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    HardwareStatTile(
                        label = "MODELO",
                        value = hardwareInfo.modelName,
                        modifier = Modifier.weight(1.25f)
                    )
                    HardwareStatTile(
                        label = "RESOLUÇÃO",
                        value = hardwareInfo.resolution,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    HardwareStatTile(
                        label = "DPI ATUAL",
                        value = "${hardwareInfo.dpi} DPI",
                        modifier = Modifier.weight(1f)
                    )
                    HardwareStatTile(
                        label = "TAXA DE TELA",
                        value = "${hardwareInfo.refreshRateHz} Hz",
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // 2. Interruptor 1 — MODO BONECO LENTO + VPN BOOST
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(GrxCardDark)
                    .border(
                        width = 1.5.dp,
                        color = if (isVpnActive) GrxNeonCyan else GrxElectricBlue.copy(alpha = 0.85f),
                        shape = RoundedCornerShape(20.dp)
                    )
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.VpnLock,
                            contentDescription = "VPN Boost",
                            tint = GrxNeonCyan,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "MODO BONECO LENTO",
                            style = MaterialTheme.typography.titleLarge.copy(
                                color = GrxWhite,
                                fontSize = 13.5.sp
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    StatusPillBadge(
                        text = if (isVpnActive) "● VPN & MODO ATIVOS" else "● DESATIVADO",
                        isActive = isVpnActive
                    )
                }

                Text(
                    text = "VPN local de baixa latência (DNS 1.1.1.1 / 8.8.8.8 • MTU 1400) para estabilizar ping, acelerar resposta e suavizar rastreamento visual.",
                    style = MaterialTheme.typography.bodyMedium.copy(color = GrxIceGray)
                )

                ConsoleNeonToggleSwitch(
                    isOn = isVpnActive,
                    onToggle = onToggleVpn,
                    testTag = "toggle_boneco_lento_vpn"
                )

                Text(
                    text = vpnStatusLog,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = if (isVpnActive) GrxNeonCyan else GrxIceGray
                    )
                )

                AnimatedVisibility(visible = isVpnActive) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(Color(0xFF062738), Color(0xFF0A1B3D))
                                )
                            )
                            .border(1.2.dp, GrxNeonCyan, RoundedCornerShape(14.dp))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.CheckCircle,
                                contentDescription = "VPN Ativa",
                                tint = GrxSuccessGreen,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "BONECO LENTO + VPN ATIVADOS ✓",
                                style = MaterialTheme.typography.labelLarge.copy(
                                    color = GrxSuccessGreen,
                                    fontSize = 12.sp
                                )
                            )
                        }
                        Text(
                            text = "Túnel de baixa latência ativo: tiro e movimentação mais rápidos, ping estabilizado e rastreamento suave de mira.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = GrxWhite)
                        )
                    }
                }
            }

            // 3. Interruptor 2 — MODO FANGRXSHOT (Execução Direta via Shizuku)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(GrxCardDark)
                    .border(
                        width = 1.5.dp,
                        color = if (fangrxshotActive) GrxNeonCyan else GrxElectricBlue.copy(alpha = 0.85f),
                        shape = RoundedCornerShape(20.dp)
                    )
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Bolt,
                            contentDescription = "FANGRXSHOT",
                            tint = GrxNeonCyan,
                            modifier = Modifier.size(22.dp)
                        )
                        Text(
                            text = "MODO FANGRXSHOT",
                            style = MaterialTheme.typography.titleLarge.copy(
                                color = GrxWhite,
                                fontSize = 13.5.sp
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    val shizukuStatusText = when {
                        shizukuConnected && shizukuPermissionGranted -> "SHIZUKU: CONECTADO"
                        shizukuConnected -> "SHIZUKU: CONECTADO"
                        else -> "SHIZUKU: AGUARDANDO"
                    }
                    StatusPillBadge(
                        text = shizukuStatusText,
                        isActive = shizukuConnected
                    )
                }

                Text(
                    text = "Execução direta via Shizuku (${FangrxshotManager.COMMANDS.size} parâmetros de toque, Vulkan HWUI, taxa 90Hz+ e memória).",
                    style = MaterialTheme.typography.bodyMedium.copy(color = GrxIceGray)
                )

                ConsoleNeonToggleSwitch(
                    isOn = fangrxshotActive,
                    isBusy = fangrxshotRunning,
                    onToggle = onToggleFangrxshot,
                    testTag = "toggle_fangrxshot_shizuku"
                )

                AnimatedVisibility(visible = fangrxshotActive) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF072336))
                            .border(1.2.dp, GrxNeonCyan, RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Speed,
                            contentDescription = "FANGRXSHOT Ativado",
                            tint = GrxSuccessGreen,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "FANGRXSHOT ATIVADO ✓  ($fangrxshotSucceededCount/${FangrxshotManager.COMMANDS.size} comandos aplicados)",
                            style = MaterialTheme.typography.labelLarge.copy(
                                color = GrxSuccessGreen,
                                fontSize = 11.5.sp
                            )
                        )
                    }
                }

                // Log rolável em Azul Neon
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF040811))
                        .border(1.dp, GrxElectricBlue.copy(alpha = 0.65f), RoundedCornerShape(12.dp))
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Terminal,
                            contentDescription = "Console Shizuku",
                            tint = GrxNeonCyan,
                            modifier = Modifier.size(15.dp)
                        )
                        Text(
                            text = "CONSOLE SHIZUKU FANGRXSHOT",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = GrxNeonCyan,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    LazyColumn(
                        state = logListState,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 72.dp, max = 148.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(fangrxshotLogs) { line ->
                            val lineColor = when {
                                line.startsWith("[OK]") -> GrxNeonCyan
                                line.startsWith("[IGN]") -> GrxWarningAmber
                                line.startsWith("[ERRO]") || line.startsWith("[BLOQUEADO]") -> GrxAlertRed
                                else -> GrxIceGray
                            }
                            Text(
                                text = line,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = lineColor,
                                    fontSize = 10.sp
                                )
                            )
                        }
                    }
                }
            }

            // 4. Botão Principal GERAR PACK OTIMIZAÇÃO (Exportação Direta para Download)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(GrxCardDark)
                    .border(1.5.dp, GrxNeonCyan, RoundedCornerShape(20.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Shield,
                        contentDescription = "Exportar Pack",
                        tint = GrxNeonCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "PACK DE OTIMIZAÇÃO OFICIAL",
                        style = MaterialTheme.typography.titleLarge.copy(
                            color = GrxWhite,
                            fontSize = 13.5.sp
                        )
                    )
                }

                Text(
                    text = "Exporta um pacote .zip completo na pasta Download contendo fangrxshot_commands.sh, grx_boneco_lento_sensi.cfg e LEIA_ME_RAYLAN.txt.",
                    style = MaterialTheme.typography.bodyMedium.copy(color = GrxIceGray)
                )

                Button(
                    onClick = onExportPack,
                    enabled = packExportState !is PackExportUiState.Exporting,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("btn_gerar_pack_otimizacao"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = GrxRoyalBlue,
                        contentColor = GrxWhite
                    ),
                    contentPadding = PaddingValues(horizontal = 16.dp)
                ) {
                    if (packExportState is PackExportUiState.Exporting) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = GrxNeonCyan,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "GERANDO PACK .ZIP...",
                            style = MaterialTheme.typography.labelLarge.copy(color = GrxWhite)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Rounded.Download,
                            contentDescription = "Baixar pack",
                            tint = GrxNeonCyan,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "GERAR PACK OTIMIZAÇÃO",
                            style = MaterialTheme.typography.labelLarge.copy(color = GrxWhite)
                        )
                    }
                }

                when (packExportState) {
                    is PackExportUiState.Exported -> {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF062335))
                                .border(1.dp, GrxSuccessGreen, RoundedCornerShape(12.dp))
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "PACK SALVO NA PASTA DOWNLOAD ✓",
                                style = MaterialTheme.typography.labelLarge.copy(
                                    color = GrxSuccessGreen,
                                    fontSize = 11.5.sp
                                )
                            )
                            Text(
                                text = packExportState.result.displayPath,
                                style = MaterialTheme.typography.labelSmall.copy(color = GrxWhite)
                            )
                            OutlinedButton(
                                onClick = onOpenDownloads,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("btn_abrir_pasta_download"),
                                shape = RoundedCornerShape(12.dp),
                                border = androidx.compose.foundation.BorderStroke(1.5.dp, GrxNeonCyan)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.FolderOpen,
                                    contentDescription = "Abrir pasta Download",
                                    tint = GrxNeonCyan,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "ABRIR PASTA DOWNLOAD",
                                    style = MaterialTheme.typography.labelLarge.copy(color = GrxNeonCyan)
                                )
                            }
                        }
                    }

                    is PackExportUiState.Error -> {
                        Text(
                            text = "Erro: ${packExportState.message}",
                            style = MaterialTheme.typography.bodyMedium.copy(color = GrxAlertRed)
                        )
                    }

                    else -> Unit
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
        }
    }
}

@Composable
private fun HardwareStatTile(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(GrxCardElevated)
            .border(1.dp, GrxElectricBlue.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = GrxNeonCyan,
                fontSize = 9.5.sp
            )
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelSmall.copy(
                color = GrxWhite,
                fontWeight = FontWeight.Bold,
                fontSize = 11.5.sp
            ),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun StatusPillBadge(
    text: String,
    isActive: Boolean
) {
    val borderColor = if (isActive) GrxSuccessGreen else GrxIceGray.copy(alpha = 0.5f)
    val textColor = if (isActive) GrxSuccessGreen else GrxIceGray
    val bgColor = if (isActive) GrxSuccessGreen.copy(alpha = 0.12f) else GrxBgDeep

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall.copy(
                color = textColor,
                fontWeight = FontWeight.Bold,
                fontSize = 9.5.sp
            ),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
