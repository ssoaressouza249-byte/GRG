package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.GppBad
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.security.SecurityGuard
import com.example.security.TamperCheckResult
import com.example.ui.theme.GrxAlertRed
import com.example.ui.theme.GrxBgDeep
import com.example.ui.theme.GrxIceGray
import com.example.ui.theme.GrxWhite

@Composable
fun TamperBlockedScreen(
    blocked: TamperCheckResult.Blocked,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "tamper_pulse")
    val borderAlpha by transition.animateFloat(
        initialValue = 0.45f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "tamper_alpha"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF1A0309), GrxBgDeep, Color(0xFF140207))
                )
            )
            .safeDrawingPadding()
            .padding(24.dp)
            .testTag("tamper_blocked_screen"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 520.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(Color(0xFF12060B))
                .border(
                    width = 2.dp,
                    color = GrxAlertRed.copy(alpha = borderAlpha),
                    shape = RoundedCornerShape(22.dp)
                )
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape)
                    .background(GrxAlertRed.copy(alpha = 0.16f))
                    .border(2.dp, GrxAlertRed, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.GppBad,
                    contentDescription = "Violação de Integridade",
                    tint = GrxAlertRed,
                    modifier = Modifier.size(44.dp)
                )
            }

            Text(
                text = "PROTEÇÃO ANTI-MODIFICAÇÃO",
                style = MaterialTheme.typography.titleLarge.copy(
                    color = GrxAlertRed,
                    letterSpacing = 1.6.sp,
                    fontWeight = FontWeight.ExtraBold
                ),
                textAlign = TextAlign.Center
            )

            Text(
                text = SecurityGuard.BLOCKED_MESSAGE,
                style = MaterialTheme.typography.titleMedium.copy(
                    color = GrxWhite,
                    fontSize = 16.sp,
                    lineHeight = 24.sp
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0A0407))
                    .border(1.dp, GrxAlertRed.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "DIAGNÓSTICO DE VIOLAÇÃO:",
                    style = MaterialTheme.typography.labelSmall.copy(color = GrxAlertRed)
                )
                Text(
                    text = blocked.violationReason,
                    style = MaterialTheme.typography.labelSmall.copy(color = GrxIceGray)
                )
                Text(
                    text = "Pacote detectado: ${blocked.observedPackage}",
                    style = MaterialTheme.typography.labelSmall.copy(color = GrxIceGray)
                )
            }
        }
    }
}
