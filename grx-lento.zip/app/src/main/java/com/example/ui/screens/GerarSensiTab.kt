package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.SensitivityProfile
import com.example.hardware.DeviceHardwareInfo
import com.example.hardware.PhoneBrand
import com.example.hardware.PlayStyle
import com.example.ui.SensitivityAiUiState
import com.example.ui.components.GojoRaylanAiBanner
import com.example.ui.theme.GrxAlertRed
import com.example.ui.theme.GrxBgDeep
import com.example.ui.theme.GrxCardDark
import com.example.ui.theme.GrxCardElevated
import com.example.ui.theme.GrxElectricBlue
import com.example.ui.theme.GrxIceGray
import com.example.ui.theme.GrxNeonCyan
import com.example.ui.theme.GrxRoyalBlue
import com.example.ui.theme.GrxSuccessGreen
import com.example.ui.theme.GrxWhite

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GerarSensiTab(
    hardwareInfo: DeviceHardwareInfo,
    selectedBrand: PhoneBrand,
    onSelectBrand: (PhoneBrand) -> Unit,
    selectedPlayStyle: PlayStyle,
    onSelectPlayStyle: (PlayStyle) -> Unit,
    aiState: SensitivityAiUiState,
    onGenerateAiSensitivity: () -> Unit,
    onNavigateBackHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onNavigateBackHome)

    val context = LocalContext.current
    val scrollState = rememberScrollState()

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxWidth()
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Banner compacto do Sistema IA GRX analisando o aparelho
            GojoRaylanAiBanner(compact = true)

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(GrxCardDark)
                    .border(1.dp, GrxElectricBlue.copy(alpha = 0.7f), RoundedCornerShape(14.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.PhoneAndroid,
                    contentDescription = "Aparelho detectado",
                    tint = GrxNeonCyan,
                    modifier = Modifier.size(22.dp)
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "ANÁLISE DE HARDWARE ATIVA",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = GrxNeonCyan,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "${hardwareInfo.modelName} • ${hardwareInfo.resolution} • ${hardwareInfo.dpi} DPI • ${hardwareInfo.refreshRateHz}Hz",
                        style = MaterialTheme.typography.bodyMedium.copy(color = GrxWhite)
                    )
                }
            }

            // 2. Seletor de Marca Especial do Celular
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(GrxCardDark)
                    .border(1.5.dp, GrxNeonCyan, RoundedCornerShape(20.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "MARCA DO CELULAR",
                    style = MaterialTheme.typography.titleLarge.copy(
                        color = GrxWhite,
                        fontSize = 13.5.sp
                    )
                )

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PhoneBrand.entries.forEach { brand ->
                        val isSelected = brand == selectedBrand
                        val isDetected = brand == hardwareInfo.detectedBrand
                        BrandChipCard(
                            brand = brand,
                            isSelected = isSelected,
                            isDetected = isDetected,
                            onClick = { onSelectBrand(brand) }
                        )
                    }
                }
            }

            // 3. Seletor de Estilo de Jogabilidade
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(GrxCardDark)
                    .border(1.5.dp, GrxElectricBlue, RoundedCornerShape(20.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Tune,
                        contentDescription = "Estilo de jogabilidade",
                        tint = GrxNeonCyan,
                        modifier = Modifier.size(19.dp)
                    )
                    Text(
                        text = "ESTILO DE JOGABILIDADE",
                        style = MaterialTheme.typography.titleLarge.copy(
                            color = GrxWhite,
                            fontSize = 13.5.sp
                        )
                    )
                }

                PlayStyle.entries.forEach { style ->
                    val isSelected = style == selectedPlayStyle
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .minimumInteractiveComponentSize()
                            .testTag("playstyle_${style.name.lowercase()}")
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                if (isSelected) Color(0xFF0A2242) else GrxCardElevated
                            )
                            .border(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) GrxNeonCyan else GrxElectricBlue.copy(alpha = 0.4f),
                                shape = RoundedCornerShape(14.dp)
                            )
                            .clickable { onSelectPlayStyle(style) }
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = style.label,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = if (isSelected) GrxNeonCyan else GrxWhite
                                )
                            )
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Rounded.CheckCircle,
                                    contentDescription = "Selecionado",
                                    tint = GrxNeonCyan,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        Text(
                            text = style.shortDesc,
                            style = MaterialTheme.typography.bodyMedium.copy(color = GrxIceGray)
                        )
                    }
                }
            }

            // 4. Botão GERAR SENSIBILIDADE COM IA
            Button(
                onClick = onGenerateAiSensitivity,
                enabled = aiState !is SensitivityAiUiState.Loading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("btn_gerar_sensi_ia"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = GrxRoyalBlue,
                    contentColor = GrxWhite
                )
            ) {
                if (aiState is SensitivityAiUiState.Loading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = GrxNeonCyan,
                        strokeWidth = 2.5.dp
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "SISTEMA IA GRX CALIBRANDO...",
                        style = MaterialTheme.typography.labelLarge.copy(color = GrxWhite)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Rounded.AutoAwesome,
                        contentDescription = "Gerar Sensibilidade IA",
                        tint = GrxNeonCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "GERAR SENSIBILIDADE COM IA",
                        style = MaterialTheme.typography.labelLarge.copy(color = GrxWhite)
                    )
                }
            }

            // Resultado / Erro da IA
            when (aiState) {
                is SensitivityAiUiState.Success -> {
                    SensitivityResultCard(
                        profile = aiState.profile,
                        onCopy = {
                            copySensitivityToClipboard(context, aiState.profile)
                        }
                    )
                }

                is SensitivityAiUiState.Error -> {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF19060B))
                            .border(1.5.dp, GrxAlertRed, RoundedCornerShape(16.dp))
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ErrorOutline,
                                contentDescription = "Erro IA",
                                tint = GrxAlertRed
                            )
                            Text(
                                text = "FALHA NO SISTEMA IA GRX",
                                style = MaterialTheme.typography.labelLarge.copy(color = GrxAlertRed)
                            )
                        }
                        Text(
                            text = aiState.message,
                            style = MaterialTheme.typography.bodyMedium.copy(color = GrxWhite)
                        )
                    }
                }

                else -> Unit
            }

            Spacer(modifier = Modifier.height(6.dp))
        }
    }
}

@Composable
private fun BrandChipCard(
    brand: PhoneBrand,
    isSelected: Boolean,
    isDetected: Boolean,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .minimumInteractiveComponentSize()
            .testTag("brand_chip_${brand.name.lowercase()}")
            .clip(RoundedCornerShape(14.dp))
            .background(
                if (isSelected) {
                    Brush.horizontalGradient(
                        colors = listOf(GrxElectricBlue.copy(alpha = 0.45f), GrxNeonCyan.copy(alpha = 0.25f))
                    )
                } else {
                    Brush.horizontalGradient(
                        colors = listOf(GrxCardElevated, GrxCardElevated)
                    )
                }
            )
            .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) GrxNeonCyan else GrxElectricBlue.copy(alpha = 0.55f),
                shape = RoundedCornerShape(14.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(
            text = brand.label,
            style = MaterialTheme.typography.titleMedium.copy(
                color = if (isSelected) GrxNeonCyan else GrxWhite,
                fontSize = 14.sp
            )
        )
        AnimatedVisibility(visible = isDetected) {
            Text(
                text = "Detectado no seu aparelho",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = GrxSuccessGreen,
                    fontSize = 9.5.sp,
                    fontWeight = FontWeight.Bold
                )
            )
        }
    }
}

@Composable
private fun SensitivityResultCard(
    profile: SensitivityProfile,
    onCopy: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(GrxCardDark)
            .border(1.5.dp, GrxNeonCyan, RoundedCornerShape(20.dp))
            .padding(16.dp)
            .testTag("sensitivity_result_card"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "PERFIL IA CALIBRADO ✓",
                    style = MaterialTheme.typography.labelLarge.copy(color = GrxSuccessGreen)
                )
                Text(
                    text = "${profile.brand} • ${profile.playstyle}",
                    style = MaterialTheme.typography.bodyMedium.copy(color = GrxIceGray)
                )
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(GrxNeonCyan.copy(alpha = 0.14f))
                    .border(1.dp, GrxNeonCyan, RoundedCornerShape(50))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "ESTAB. ${profile.estabilidadeMira}%",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = GrxNeonCyan,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }

        SensitivitySliderBar(label = "GERAL", value = profile.geral)
        SensitivitySliderBar(label = "PONTO VERMELHO", value = profile.pontoVermelho)
        SensitivitySliderBar(label = "MIRA 2X", value = profile.mira2x)
        SensitivitySliderBar(label = "MIRA 4X", value = profile.mira4x)
        SensitivitySliderBar(label = "AWM", value = profile.awm)
        SensitivitySliderBar(label = "OLHADINHA", value = profile.olhadinha)

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ExtraParamChip(
                label = "DPI / AJUSTE",
                value = profile.dpiRecomendada,
                modifier = Modifier.weight(1f)
            )
            ExtraParamChip(
                label = "BOTÃO TIRO",
                value = profile.tamanhoBotaoTiro,
                modifier = Modifier.weight(1f)
            )
        }

        ExtraParamChip(
            label = "VELOCIDADE PONTEIRO",
            value = profile.velocidadePonteiro,
            modifier = Modifier.fillMaxWidth()
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF06162A))
                .border(1.dp, GrxElectricBlue.copy(alpha = 0.65f), RoundedCornerShape(12.dp))
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = "ANÁLISE TÁTICA IA GRX",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = GrxNeonCyan,
                    fontWeight = FontWeight.Bold
                )
            )
            Text(
                text = profile.dicaTecnicaIA,
                style = MaterialTheme.typography.bodyMedium.copy(color = GrxWhite)
            )
        }

        OutlinedButton(
            onClick = onCopy,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("btn_copiar_sensi"),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.5.dp, GrxNeonCyan)
        ) {
            Icon(
                imageVector = Icons.Rounded.ContentCopy,
                contentDescription = "Copiar configuração",
                tint = GrxNeonCyan,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "COPIAR PERFIL COMPLETO",
                style = MaterialTheme.typography.labelLarge.copy(color = GrxNeonCyan)
            )
        }
    }
}

@Composable
private fun SensitivitySliderBar(
    label: String,
    value: Int
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(color = GrxIceGray)
            )
            Text(
                text = "$value / 200",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = GrxNeonCyan,
                    fontWeight = FontWeight.Bold
                )
            )
        }
        LinearProgressIndicator(
            progress = { (value / 200f).coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(7.dp)
                .clip(RoundedCornerShape(50)),
            color = GrxNeonCyan,
            trackColor = GrxBgDeep
        )
    }
}

@Composable
private fun ExtraParamChip(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(GrxCardElevated)
            .border(1.dp, GrxElectricBlue.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = GrxNeonCyan,
                fontSize = 9.5.sp
            )
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelSmall.copy(
                color = GrxWhite,
                fontWeight = FontWeight.Bold
            )
        )
    }
}

private fun copySensitivityToClipboard(context: Context, profile: SensitivityProfile) {
    val text = buildString {
        appendLine("GRX LENTO — SENSIBILIDADE IA (${profile.brand})")
        appendLine("Estilo: ${profile.playstyle}")
        appendLine("Geral: ${profile.geral}")
        appendLine("Ponto Vermelho: ${profile.pontoVermelho}")
        appendLine("Mira 2x: ${profile.mira2x}")
        appendLine("Mira 4x: ${profile.mira4x}")
        appendLine("AWM: ${profile.awm}")
        appendLine("Olhadinha: ${profile.olhadinha}")
        appendLine("DPI / Ajuste: ${profile.dpiRecomendada}")
        appendLine("Botão de Atirar: ${profile.tamanhoBotaoTiro}")
        appendLine("Ponteiro: ${profile.velocidadePonteiro}")
        appendLine("Criador Oficial: RAYLAN GRX")
    }
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText("GRX LENTO Sensibilidade", text))
    Toast.makeText(context, "Sensibilidade copiada para a área de transferência!", Toast.LENGTH_SHORT).show()
}
