package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

private val GrxDarkColorScheme = darkColorScheme(
    primary = GrxNeonCyan,
    onPrimary = GrxBgDeep,
    primaryContainer = GrxRoyalBlue,
    onPrimaryContainer = GrxWhite,
    secondary = GrxElectricBlue,
    onSecondary = GrxWhite,
    secondaryContainer = GrxCardElevated,
    onSecondaryContainer = GrxNeonCyan,
    tertiary = GrxSuccessGreen,
    onTertiary = GrxBgDeep,
    background = GrxBgDeep,
    onBackground = GrxWhite,
    surface = GrxCardDark,
    onSurface = GrxWhite,
    surfaceVariant = GrxCardElevated,
    onSurfaceVariant = GrxIceGray,
    outline = GrxNeonCyan,
    outlineVariant = GrxElectricBlue,
    error = GrxAlertRed,
    onError = GrxWhite
)

private val GrxShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp)
)

@Composable
fun GrxLentoTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = GrxDarkColorScheme,
        typography = GrxTypography,
        shapes = GrxShapes,
        content = content
    )
}
