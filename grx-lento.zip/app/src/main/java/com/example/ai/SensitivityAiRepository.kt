package com.example.ai

import com.example.hardware.DeviceHardwareInfo
import com.example.hardware.PhoneBrand
import com.example.hardware.PlayStyle
import kotlinx.coroutines.delay

data class SensitivityProfile(
    val brand: String,
    val playstyle: String,
    val geral: Int,
    val pontoVermelho: Int,
    val mira2x: Int,
    val mira4x: Int,
    val awm: Int,
    val olhadinha: Int,
    val dpiRecomendada: String,
    val tamanhoBotaoTiro: String,
    val velocidadePonteiro: String,
    val estabilidadeMira: Int,
    val dicaTecnicaIA: String
)

class SensitivityAiRepository {

    suspend fun generateSensitivity(
        brand: PhoneBrand,
        playstyle: PlayStyle,
        hardware: DeviceHardwareInfo
    ): SensitivityProfile {
        delay(850L)

        val brandOffset = when (brand) {
            PhoneBrand.SAMSUNG -> 4
            PhoneBrand.XIAOMI_POCO -> -3
            PhoneBrand.MOTOROLA -> 6
            PhoneBrand.REALME -> 2
            PhoneBrand.ASUS_ROG -> -5
            PhoneBrand.INFINIX_TECNO -> 8
            PhoneBrand.IPHONE_IOS -> 0
            PhoneBrand.OTHER_ANDROID -> 3
        }

        val hzBonus = if (hardware.refreshRateHz >= 90) 4 else 0

        val (baseGeral, baseRed, base2x, base4x, baseAwm, baseLook, stability, tip) = when (playstyle) {
            PlayStyle.BONECO_LENTO -> listOf(
                156 + brandOffset,
                148 + brandOffset,
                138 + brandOffset,
                124 + brandOffset,
                84,
                115,
                97,
                "Calibração Boneco Lento (${brand.label}): arraste controlado sem tremedeira para acompanhar a cabeça do alvo com precisão."
            )
            PlayStyle.ONE_TAP -> listOf(
                184 + brandOffset + hzBonus,
                176 + brandOffset,
                168 + brandOffset,
                154 + brandOffset,
                96,
                132,
                93,
                "Calibração One-Tap (${brand.label}): puxada curta e firme no botão de atirar para encaixar capa rápido."
            )
            PlayStyle.RUSH_MOVEMENT -> listOf(
                194 + brandOffset,
                188 + brandOffset,
                178 + brandOffset,
                162 + brandOffset,
                104,
                155,
                90,
                "Calibração Rush 360 (${brand.label}): giro instantâneo para gelo agachado e trocação de curta distância."
            )
        }

        val recommendedDpi = if (brand == PhoneBrand.IPHONE_IOS) {
            "Cursor Móvel: Refinado 118"
        } else {
            val calcDpi = when (playstyle) {
                PlayStyle.BONECO_LENTO -> (hardware.dpi + 140).coerceIn(480, 760)
                PlayStyle.ONE_TAP -> (hardware.dpi + 220).coerceIn(540, 860)
                PlayStyle.RUSH_MOVEMENT -> (hardware.dpi + 280).coerceIn(600, 960)
            }
            "$calcDpi DPI"
        }

        val fireButton = when (playstyle) {
            PlayStyle.BONECO_LENTO -> "48%"
            PlayStyle.ONE_TAP -> "42%"
            PlayStyle.RUSH_MOVEMENT -> "45%"
        }

        return SensitivityProfile(
            brand = brand.label,
            playstyle = playstyle.label,
            geral = (baseGeral as Int).coerceIn(50, 200),
            pontoVermelho = (baseRed as Int).coerceIn(50, 200),
            mira2x = (base2x as Int).coerceIn(50, 200),
            mira4x = (base4x as Int).coerceIn(50, 200),
            awm = (baseAwm as Int).coerceIn(50, 200),
            olhadinha = (baseLook as Int).coerceIn(50, 200),
            dpiRecomendada = recommendedDpi,
            tamanhoBotaoTiro = fireButton,
            velocidadePonteiro = "Máxima (Nível 7)",
            estabilidadeMira = stability as Int,
            dicaTecnicaIA = tip as String
        )
    }
}
