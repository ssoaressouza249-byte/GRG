package com.example.shizuku

import android.content.Context
import android.content.pm.PackageManager
import com.example.security.SecurityGuard
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import java.lang.reflect.Method

data class ShizukuCommandResult(
    val command: String,
    val success: Boolean,
    val detail: String
)

data class FangrxshotSummary(
    val totalCommands: Int,
    val succeededCount: Int,
    val logs: List<String>
)

object FangrxshotManager {

    const val SHIZUKU_PERMISSION_REQUEST_CODE = 1001

    val COMMANDS: List<String> = listOf(
        "settings put system pointer_speed 7",
        "settings put system mouse_acceleration 0",
        "settings put system hardware_acceleration true",
        "settings put global custom_pointer_speed_multiplier 100.0",
        "settings put secure touch_h_scale 50.0",
        "settings put secure touch_v_scale 42.0",
        "settings put system touch_sensitivity 5.0",
        "settings put system user_touch_response 1",
        "setprop debug.input.velocitytracker.strategy baseline",
        "setprop touch.coverage.calibration box",
        "setprop touch.device.mode navigation",
        "settings put secure controller_y_axis_sensitivity 0.72",
        "settings put global touch_distance_scale 0.0001",
        "settings put secure touch_blocking_period 0.000001",
        "settings put global touch_pixel_snapping 1",
        "setprop debug.input.filter_noise false",
        "setprop aim_sensitivity_transition_time 0.00",
        "setprop ro.input.no_hover 1",
        "setprop debug.input.touch_jitter_filter false",
        "setprop ro.input.filter_touch_events 0",
        "settings put global motion_prediction_enabled 1",
        "setprop persist.device_config.motion_prediction.enable_prediction true",
        "settings put global view_touch_friction 0.0",
        "setprop ro.tabs.default_friction 0",
        "setprop debug.hwui.render_thread_policy 1",
        "setprop debug.sf.early_phase_offset_ns 0",
        "setprop persist.sys.use_fifo_ui 1",
        "settings put system peak_refresh_rate 90.0",
        "settings put system min_refresh_rate 90.0",
        "setprop debug.hwui.renderer skiavk",
        "setprop debug.sf.latch_unsignaled true",
        "setprop persist.sys.input.boost 1",
        "setprop debug.hwui.disabled_features 0",
        "setprop persist.sys.game_mode 2",
        "setprop debug.egl.force_vulkan 1",
        "setprop debug.gr.vblank_disable true",
        "setprop debug.sf.disable_hwc_vblank 1",
        "setprop debug.hwui.overdraw false",
        "setprop debug.sf.disable_client_composition_cache 1",
        "setprop debug.unity.allow_low_latency 1",
        "setprop debug.unity.gles3_only 1",
        "setprop debug.sf.high_fps_late_app_phase_offset_ns 0",
        "setprop persist.sys.game.perf_mode 1",
        "setprop debug.hwui.skip_empty_shading_passes true",
        "settings put global view_scroll_friction 0.0",
        "setprop debug.unity.allow_raw_input 1",
        "settings put secure touch_accessibility_enhancement 1",
        "cmd device_config put activity_manager max_phantom_processes 0",
        "pm trim-caches 9999999999",
        "am kill-all"
    )

    private val newProcessMethod: Method by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        ).apply {
            isAccessible = true
        }
    }

    fun isShizukuAvailable(): Boolean = runCatching {
        Shizuku.pingBinder()
    }.getOrDefault(false)

    fun hasShizukuPermission(): Boolean {
        if (!isShizukuAvailable()) return false
        return runCatching {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)
    }

    fun isShizukuAppInstalled(context: Context): Boolean {
        return runCatching {
            context.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0)
            true
        }.getOrDefault(false)
    }

    suspend fun executeAllCommands(
        context: Context,
        onProgress: (index: Int, total: Int, logLine: String) -> Unit
    ): FangrxshotSummary = withContext(Dispatchers.IO) {
        if (!SecurityGuard.isIntact(context)) {
            return@withContext FangrxshotSummary(
                totalCommands = COMMANDS.size,
                succeededCount = 0,
                logs = listOf("[BLOQUEADO] Integridade violada. Execução cancelada.")
            )
        }

        val logs = mutableListOf<String>()
        var succeeded = 0

        COMMANDS.forEachIndexed { idx, cmd ->
            val result = executeSingleCommand(cmd)
            if (result.success) succeeded++
            val prefix = if (result.success) "[OK]" else "[IGN]"
            val line = "$prefix (${idx + 1}/${COMMANDS.size}) ${result.command}" +
                if (!result.success && result.detail.isNotBlank()) " -> ${result.detail}" else ""
            logs.add(line)
            onProgress(idx + 1, COMMANDS.size, line)
        }

        FangrxshotSummary(
            totalCommands = COMMANDS.size,
            succeededCount = succeeded,
            logs = logs
        )
    }

    private fun executeSingleCommand(command: String): ShizukuCommandResult {
        return try {
            val process = newProcessMethod.invoke(
                null,
                arrayOf("sh", "-c", command),
                null,
                null
            ) as Process

            val stderr = BufferedReader(InputStreamReader(process.errorStream)).use {
                it.readText().trim()
            }
            val exitCode = process.waitFor()
            if (exitCode == 0) {
                ShizukuCommandResult(command = command, success = true, detail = "Aplicado")
            } else {
                val reason = stderr.lineSequence().firstOrNull().orEmpty()
                    .ifBlank { "requer privilégio root (exit $exitCode)" }
                ShizukuCommandResult(command = command, success = false, detail = reason)
            }
        } catch (e: Exception) {
            ShizukuCommandResult(
                command = command,
                success = false,
                detail = e.cause?.localizedMessage ?: e.localizedMessage ?: "erro Shizuku"
            )
        }
    }
}
