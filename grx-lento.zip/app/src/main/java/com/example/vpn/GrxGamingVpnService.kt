package com.example.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.security.SecurityGuard
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object VpnStateHolder {
    private val _isVpnActive = MutableStateFlow(false)
    val isVpnActive: StateFlow<Boolean> = _isVpnActive.asStateFlow()

    private val _statusLog = MutableStateFlow("Túnel VPN local em espera.")
    val statusLog: StateFlow<String> = _statusLog.asStateFlow()

    internal fun updateState(active: Boolean, log: String) {
        _isVpnActive.value = active
        _statusLog.value = log
    }
}

class GrxGamingVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!SecurityGuard.isIntact(this)) {
            Log.e(TAG, "SecurityGuard blocked VPN start.")
            stopVpn()
            return START_NOT_STICKY
        }

        return when (intent?.action) {
            ACTION_STOP -> {
                stopVpn()
                START_NOT_STICKY
            }
            else -> {
                startVpn()
                START_STICKY
            }
        }
    }

    private fun startVpn() {
        createNotificationChannel()
        val notification = buildNotification()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        if (vpnInterface != null) {
            VpnStateHolder.updateState(
                active = true,
                log = "DNS 1.1.1.1 / 8.8.8.8 • MTU 1400 • Rota direta ativa"
            )
            return
        }

        try {
            val builder = Builder()
                .setSession("GRX LENTO VPN")
                .setMtu(1400)
                .addAddress("10.10.24.2", 32)
                // Rota direta na sub-rede local do túnel sem reter tráfego 0.0.0.0/0,
                // mantendo internet normal com DNS gaming de baixa latência e MTU 1400.
                .addRoute("10.10.24.0", 24)
                .addDnsServer("1.1.1.1")
                .addDnsServer("8.8.8.8")

            runCatching { builder.addDisallowedApplication(packageName) }

            vpnInterface = builder.establish()
            if (vpnInterface != null) {
                VpnStateHolder.updateState(
                    active = true,
                    log = "DNS 1.1.1.1 / 8.8.8.8 • MTU 1400 • Túnel local ativo"
                )
            } else {
                VpnStateHolder.updateState(
                    active = false,
                    log = "Permissão VPN não concedida pelo sistema."
                )
                stopSelf()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao estabelecer interface VPN", e)
            VpnStateHolder.updateState(
                active = false,
                log = "Falha ao iniciar VPN: ${e.localizedMessage ?: "erro desconhecido"}"
            )
            stopVpn()
        }
    }

    private fun stopVpn() {
        runCatching {
            vpnInterface?.close()
        }
        vpnInterface = null
        VpnStateHolder.updateState(
            active = false,
            log = "Túnel VPN encerrado."
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
    }

    override fun onRevoke() {
        stopVpn()
        super.onRevoke()
    }

    override fun onDestroy() {
        runCatching { vpnInterface?.close() }
        vpnInterface = null
        VpnStateHolder.updateState(false, "Túnel VPN encerrado.")
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.vpn_notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.vpn_notification_channel_desc)
                enableLights(true)
                lightColor = NEON_CYAN_ARGB
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            10,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = PendingIntent.getService(
            this,
            11,
            Intent(this, GrxGamingVpnService::class.java).apply {
                action = ACTION_STOP
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(getString(R.string.vpn_notification_title))
            .setContentText(getString(R.string.vpn_notification_text))
            .setColor(NEON_CYAN_ARGB)
            .setColorized(true)
            .setOngoing(true)
            .setContentIntent(openAppIntent)
            .addAction(
                android.R.drawable.ic_media_pause,
                "Desativar VPN",
                stopIntent
            )
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    companion object {
        private const val TAG = "GrxGamingVpnService"
        private const val CHANNEL_ID = "grx_lento_vpn_channel"
        private const val NOTIFICATION_ID = 2401
        private const val NEON_CYAN_ARGB = 0xFF00E5FF.toInt()
        const val ACTION_START = "com.raylan.grxlento.action.START_VPN"
        const val ACTION_STOP = "com.raylan.grxlento.action.STOP_VPN"
    }
}
